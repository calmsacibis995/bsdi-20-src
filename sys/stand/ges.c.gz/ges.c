/*-
 * Copyright (c) 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI ges.c,v 2.1 1995/02/03 08:35:41 polk Exp
 */

static char *errlist[] = {
	"unknown error",
	"generic I/O error",
	"bad controller",
	"bad drive",
	"bad adapter",
	"bad file descriptor",
	"operation not supported",
	"file too big",
	"no such file or directory",
	"invalid argument",
	"path component not a directory",
	"read only file system",
	"can't read disk label",
	"unlabeled disk",
	"bad device specification"
	"numeric argument out of range"
};


char *
ges(code)
	int code;
{

	if ((unsigned)code >= sizeof errlist / sizeof (char *))
		code = 0;
	return (errlist[code]);
}
