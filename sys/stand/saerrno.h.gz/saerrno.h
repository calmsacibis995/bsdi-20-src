/*
 * Copyright (c) 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI saerrno.h,v 2.1 1995/02/03 08:36:23 polk Exp
 */

#define	EIO		1
#define ECTLR		2
#define EUNIT		3
#define EADAPT		4
#define EBADF		5
#define EOPNOTSUPP	6
#define EFBIG		7
#define ENOENT		8
#define EINVAL		9
#define ENOTDIR		10
#define EROFS		11
#define ERDLAB		12
#define EPART		13
#define ENXIO		14
#define ERANGE		15

