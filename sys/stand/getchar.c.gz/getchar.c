/*-
 * Copyright (c) 1992, 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI getchar.c,v 2.1 1995/02/03 08:35:46 polk Exp
 */

#include <stand/stand.h>

/* echoing version of getchar; does not echo editing control characters */
int
getchar()
{
	int c;

	c = cngetc();
	if (c == '\025' || c == '\027' || c == '\b' || c == '\177')
		return (c);
	if (c == '\r')
		c = '\n';
	putchar(c);
	return (c);
}
