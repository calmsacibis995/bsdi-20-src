/*
 * Copyright (c) 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI index.c,v 2.1 1995/02/03 08:35:57 polk Exp
 */

#include <stand/stand.h>

char *
index(p, ch)
	register const char *p;
	register int ch;
{
	do {
		if (*p == ch)
			return ((char *)p);
	} while (*p++);
	return ((char *)NULL);
}
