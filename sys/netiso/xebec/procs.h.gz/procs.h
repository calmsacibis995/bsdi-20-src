/* /master/sys/netiso/xebec/procs.h,v 2.1 1995/02/03 08:29:36 polk Exp */
/* /master/sys/netiso/xebec/procs.h,v */

extern char *stash();
extern struct Object *SameState;
