/* /master/sys/netiso/xebec/malloc.h,v 2.1 1995/02/03 08:29:26 polk Exp */
/* /master/sys/netiso/xebec/malloc.h,v */

char *Malloc();
