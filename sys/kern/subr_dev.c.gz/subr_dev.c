/*
 * Copyright (c) 1994 Berkeley Software Design Inc.  All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI subr_dev.c,v 2.1 1995/02/03 07:53:11 polk Exp
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/buf.h>
#include <sys/conf.h>
#include <sys/device.h>
#include <sys/malloc.h>
#include <sys/vnode.h>

/*
 * Temporary(?) file for dealing with block/char device translations,
 * verifications, etc.
 */

/*
 * Routine to determine if a device is a disk.
 * XXX: assumes no disk pseudo-devices, or that they have
 * config drivers with class DV_DISK.
 */
int
isdisk(dev, type)
	dev_t dev;
	int type;
{
	register struct devsw *dp;
	register struct cfdriver *cd;
	register int i;

	/* Translate block/char device to master device switch. */
	i = major(dev);
	if ((u_int)i >= ndevsw)
		return (0);
	/* It is a disk if it has a configuration driver of class DV_DISK. */
	if ((dp = devsw[i]) == NULL || (cd = dp->d_cd) == NULL)
		return (0);
	return (cd->cd_class == DV_DISK);
}
