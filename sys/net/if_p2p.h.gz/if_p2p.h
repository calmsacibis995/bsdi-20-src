/*-
 * Copyright (c) 1993, 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI if_p2p.h,v 2.1 1995/02/03 08:10:54 polk Exp
 */

/*
 * The point-to-point protocols' common data structure
 */

#include <net/if_c_hdlcvar.h>		/* XXX */
#include <net/pppvar.h>			/* XXX */

struct p2pcom {
	struct	ifnet p2p_if;		/* network-visible interface */
	int	p2p_oldflags;		/* the old flags */
	int	(*p2p_input) __P((struct p2pcom *, struct mbuf *));
	int	(*p2p_modem) __P((struct p2pcom *, int));  /* modem event */
	int	(*p2p_mdmctl) __P((struct p2pcom *, int)); /* modem control */
	int	(*p2p_xmit) __P((struct p2pcom *, struct mbuf *));
	struct	ifqueue p2p_isnd;	/* queue for interactive packets */

	struct	p2pcom *p2p_next;	/* next structure in protocol's list */
	struct	p2pcom **p2p_prevp;	/* prev. structure in protocol's list */
#ifdef notyet
	void	*p2p_private;		/* protocol private data */
#else
	/* XXX  The following should be separately allocated */
	union {
		struct	slarp_sc slarp;	/* SLARP data */
		struct	ppp_sc ppp;	/* PPP data */
	} p2p_u;
#define	p2p_slarp	p2p_u.slarp
#define	p2p_ppp		p2p_u.ppp
#endif
};

/*
 * The table of available point-to-point encapsulation protocols
 */
struct p2pprotosw {
	int	(*pp_init)();		/* protocol initialization routine */
	void	(*pp_shutdown)();	/* protocol shutdown routine */
	int	(*pp_output)();		/* output encapsulation routine */
	int	(*pp_input)();		/* the input parsing routine */
	int	(*pp_ioctl)();		/* protocol-specific ioctl */
	int	(*pp_modem)();		/* modem event */
	int	pp_type;		/* interface type for ifnet */
};

#define	HDLCMTU		1500		/* MTU for sync lines */
#define	HDLCMAX		(HDLCMTU + 8)	/* Max packet size (with link-level overhead) */

/* Check for limit of 2 queues */
#define IF_QFULL2(normal_q, fast_q) \
	((normal_q)->ifq_len + (fast_q)->ifq_len >= (normal_q)->ifq_maxlen)

#ifdef KERNEL
int	p2p_init __P((struct p2pcom *));
void	p2p_shutdown __P((struct p2pcom *));
int	p2p_ioctl __P((struct ifnet *, int, caddr_t));
extern	struct p2pprotosw p2pprotosw[];
extern	int np2pproto;
#endif
