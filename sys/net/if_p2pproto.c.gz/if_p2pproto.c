/*-
 * Copyright (c) 1993, 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI if_p2pproto.c,v 2.1 1995/02/03 08:11:00 polk Exp
 */

/*
 * Common code for point-to-point synchronous serial links
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/kernel.h>
#include <sys/malloc.h>
#include <sys/mbuf.h>
#include <sys/protosw.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#include <net/if.h>
#include <net/netisr.h>
#include <net/route.h>
#include <net/if_dl.h>
#include <net/if_types.h>

#if INET
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>		/* XXX for slcompress */
#endif

#include <net/if_p2p.h>


/*
 * Get link-level protocol # from ifnet.
 * Currently it is IFF_LINKn flags (actually only LINK0).
 * It will be changed later.
 */
#define	P2P_PROTO_TYPE(pp)	(((pp)->p2p_if.if_flags & IFF_LINK0) ? 1 : 0)


#ifdef CISCO_HDLC
extern int c_hdlc_init(), c_hdlc_output(), c_hdlc_input();
extern void c_hdlc_shutdown();
#endif
#ifdef PPP
extern int ppp_init(), ppp_output(), ppp_input(), ppp_ioctl(), ppp_modem();
extern void ppp_shutdown();
#endif

/*
 * The table of available point-to-point encapsulation protocols
 */
struct p2pprotosw p2pprotosw[] = {
	/* CISCO HDLC */
#ifdef CISCO_HDLC
{	c_hdlc_init,	c_hdlc_shutdown, c_hdlc_output,
	c_hdlc_input,	0,		0,		IFT_PTPSERIAL,
},
#else
{	0,		0,		0,
	0,		0,		0,		0,
},
#endif

	/* PPP */
#ifdef PPP
{	ppp_init,	ppp_shutdown,	ppp_output,
	ppp_input,	ppp_ioctl,	ppp_modem,	IFT_PPP,
},
#else
{	0,		0,		0,
	0,		0,		0,		0,
},
#endif
};

int np2pproto = (sizeof p2pprotosw / sizeof p2pprotosw[0]);
