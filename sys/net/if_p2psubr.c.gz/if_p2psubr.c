/*-
 * Copyright (c) 1993, 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI if_p2psubr.c,v 2.1 1995/02/03 08:11:06 polk Exp
 */

/*
 * Common code for point-to-point synchronous serial links
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/kernel.h>
#include <sys/malloc.h>
#include <sys/mbuf.h>
#include <sys/protosw.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/syslog.h>

#include <net/if.h>
#include <net/netisr.h>
#include <net/route.h>
#include <net/if_dl.h>
#include <net/if_types.h>

#include <net/if_p2p.h>


/*
 * Get link-level protocol # from ifnet.
 * Currently it is IFF_LINKn flags (actually only LINK0).
 * It will be changed later.
 */
#define	P2P_PROTO_TYPE(pp)	(((pp)->p2p_if.if_flags & IFF_LINK0) ? 1 : 0)


extern int np2pproto;

/*
 * Point-to-point interface initialization.
 * Checks the protocol number and calls the
 * protocol initialization routine.
 */
int
p2p_init(pp)
	struct p2pcom *pp;
{
	register struct ifnet *ifp = &pp->p2p_if;
	short type;

	type = P2P_PROTO_TYPE(pp);
	if (type >= np2pproto || p2pprotosw[type].pp_init == 0)
		return (EPFNOSUPPORT);
	if (ifp->if_output != p2pprotosw[type].pp_output) {
		bzero((caddr_t) &pp->p2p_u, sizeof pp->p2p_u);
		ifp->if_output = p2pprotosw[type].pp_output;
		pp->p2p_input = p2pprotosw[type].pp_input;
		pp->p2p_modem = p2pprotosw[type].pp_modem;
		ifp->if_type = p2pprotosw[type].pp_type;
	}
	return ((*p2pprotosw[type].pp_init)(pp));
}

/*
 * Point-to-point interface shutdown.
 * Checks the protocol number and calls the
 * protocol initialization routine.
 */
void
p2p_shutdown(pp)
	struct p2pcom *pp;
{
	short type;

	type = P2P_PROTO_TYPE(pp);
	if (type >= np2pproto)
		panic("p2p_shutdown");
	(*p2pprotosw[type].pp_shutdown)(pp);
}

/*
 * Handle protocol-specific ioctl
 */
int
p2p_ioctl(ifp, cmd, data)
	register struct ifnet *ifp;
	int cmd;
	caddr_t data;
{
	struct p2pcom *pp = (struct p2pcom *) ifp;
	struct ifreq *ifr;
	short type, otype;
	int error;
	int s;

	/*
	 * Call the protocol-specific ioctl handler
	 */
	type = P2P_PROTO_TYPE(pp);
	if (type >= np2pproto)
		panic("p2p_ioctl");
	s = splimp();
	if (p2pprotosw[type].pp_ioctl) {
		error = (*p2pprotosw[type].pp_ioctl)(pp, cmd, data);
		if (error != EINVAL)
			goto out;
	}

	/*
	 * Process the common ioctls
	 */
	error = 0;
	switch (cmd) {
	default:
		error = EINVAL;
		goto out;

	case SIOCSIFADDR:
		ifp->if_flags |= IFF_UP;
		break;

	case SIOCSIFDSTADDR:
	case SIOCSIFFLAGS:
		break;

	/*
	 * These should probably be done at a lower level,
	 * but this should be ok for now.
	 */
	case SIOCADDMULTI:
	case SIOCDELMULTI:
		ifr = (struct ifreq *)data;
		if (ifr == 0) {
			error = EAFNOSUPPORT;		/* XXX */
			break;
		}
		switch (ifr->ifr_addr.sa_family) {
#ifdef INET
		case AF_INET:
			break;
#endif
		default:
			error = EAFNOSUPPORT;
			break;
		}
		break;
	}

	/*
	 * IFF_UP has been changed -- initialize/shutdown
	 * the link-level protocol.
	 */
	if ((pp->p2p_oldflags ^ ifp->if_flags) & IFF_UP) {
		if (ifp->if_flags & IFF_UP) {
			if (error = p2p_init(pp))
				goto out;
		} else
			p2p_shutdown(pp);
	}
	pp->p2p_oldflags = ifp->if_flags;

	/*
	 * Switching the protocol "on the fly"
	 * (shouldn't normally happen...)
	 */
	if ((ifp->if_flags & IFF_UP) && ifp->if_output &&
	    p2pprotosw[type].pp_output != ifp->if_output) {
		for (otype = 0; otype < np2pproto; otype++)
			if (p2pprotosw[otype].pp_output == ifp->if_output)
				break;
		(*p2pprotosw[otype].pp_shutdown)(pp);
		if (error = p2p_init(pp))
			goto out;
	}
out:
	splx(s);
	return (error);
}
