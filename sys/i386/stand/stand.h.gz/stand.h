/*-
 * Copyright (c) 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI stand.h,v 2.1 1995/02/03 07:49:22 polk Exp
 */

#define WD_MAJORDEV	3	/* from conf.c */
#define FD_MAJORDEV	9	/* from conf.c */
#define SD_MAJORDEV	18	/* from conf.c */
#define BD_MAJORDEV	0

#ifndef SMALL
#define	KB_ABORT			/* abort I/O on keyboard input */
#endif

/* convert kilobytes to a multiple of the page size, in bytes */
#define k2truncpage(k)  (((k) * 1024) &~ (NBPG - 1))


#ifndef LOCORE
/*
 * Machine-dependent fields in standalone file structure.
 */
typedef struct iob {
	int	i_adapt;	/* adapter (XXX) */
	int	i_ctlr;		/* controller index */
	int	i_unit;		/* disk unit */
	int	i_part;		/* and partition */
	daddr_t	i_boff;
	struct	open_file *i_open_file;

	daddr_t	is_bn;		/* only used by scsi */
	char	*is_ma;		/* only used by scsi */
	u_int	is_cc;		/* only used by scsi */

} iob_t;


struct boot_options {
	int	o_basemem;
	int	o_searchend;		/* -1 means use CMOS */
	int	o_extmem;
	int	o_changedisk;
	int	o_howto;
	int	o_loaded;
	int	o_entry;
};

void	wait __P((int));
void	configure __P((void));
void	sizemem __P((struct boot_options *));
extern	int bootdebug;
#endif
