/*
 * Copyright (c) 1991, 1992, 1994 Berkeley Software Design, Inc.
 * All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI md-i386.c,v 2.1 1995/02/03 07:49:00 polk Exp
 *
 * Machine-dependent code for devops lookup.
 */

#include <sys/param.h>
#include <sys/reboot.h>

#include <stand/stand.h>
#include <i386/stand/stand.h>
#include <string.h>

int	bootdebug = 0;		/* initialize to make patching easy */

#ifdef SMALL
/*
 * Small bootstraps have only one driver; propagate its
 * information and return its ops pointer.
 */

int
devopen(f)
	struct open_file *f;
{
	extern int bootdev;
	extern struct devsw devops;
	static struct iob iob;

	iob.i_adapt = B_ADAPTOR(bootdev);
	iob.i_ctlr = B_CONTROLLER(bootdev);
	iob.i_unit = B_UNIT(bootdev);
	iob.i_part = B_PARTITION(bootdev);
	iob.i_open_file = f;
	f->f_dev = &devops;
	f->f_devdata = &iob;
	return (devops.dv_open((void*)&iob));
}

#else /* SMALL */

/*
 * Full-size bootstraps have multiple drivers, named via xx(args).
 */

int	opendev;

int
devopen(f, spec, filename)
	struct open_file *f;
	char *spec, **filename;
{
	register int i, d;
	int len;
	char *params;
	char *p;
	int nparam = 0;
	int paramval[4];
	extern int bootdev;
	extern int ndevs;
	extern struct devsw *devsw[];
	struct iob *io;

	/*
	 * Parse the file spec.
	 * First step: get the device name and map it to a device number.
	 */
	if ((params = index(spec, '(')) == 0) {
		*filename = spec;
		io = alloc (sizeof *io);
		opendev = bootdev;
		io->i_open_file = f;
		f->f_devdata = io;
		io->i_adapt = B_ADAPTOR(bootdev);
		io->i_ctlr = B_CONTROLLER(bootdev);
		io->i_unit = B_UNIT(bootdev);
		io->i_part = B_PARTITION(bootdev);
		f->f_dev = devsw[B_TYPE(bootdev)];
		return (f->f_dev->dv_open((void*)io));
	}

	len = params - spec;

	for (d = 0; d < ndevs; ++d)
		if (devsw[d] && devsw[d]->dv_name &&
		    strlen(devsw[d]->dv_name) == len &&
		    bcmp(devsw[d]->dv_name, spec, len) == 0)
			goto found;
	return (ENXIO);
found:
	/*
	 * Find closing parenthesis.
	 */
	if ((p = index(params, ')')) == 0)
		return (EINVAL);
	*filename = p + 1;

	io = alloc (sizeof *io);
	io->i_open_file = f;
	f->f_devdata = io;
	f->f_dev = devsw[d];

	/*
	 * Parse the comma-delimited list of numbers in the spec.
	 * It looks like this: [[[[adapter,] controller,] unit,] part]
	 * Missing values are assumed to be 0.
	 */
	for (++params; nparam < 4; params = p + 1) {
		paramval[nparam++] = strtol(params, &p, 0);
		if (*p == ')')
			break;
		if (*p != ',')
			return (EINVAL);
	}
	if (*p != ')')
		return (EINVAL);
	i = 0;
	io->i_adapt = io->i_ctlr = io->i_unit = 0;
	switch (nparam) {
	case 4:
		io->i_adapt = paramval[i++];
	case 3:
		io->i_ctlr = paramval[i++];
	case 2:
		io->i_unit = paramval[i++];
	case 1:
		io->i_part = paramval[i++];
	case 0:
		break;
	}
	opendev = MAKEBOOTDEV(d, io->i_adapt, io->i_ctlr,
	    io->i_unit, io->i_part);
	return (f->f_dev->dv_open((void*)io));
}

#endif /* !SMALL */
