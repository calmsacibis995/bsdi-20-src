/*-
 * Copyright (c) 1994 Berkeley Software Design, Inc.
 * All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI cons.c,v 2.1 1995/02/03 07:48:26 polk Exp
 */

#include <i386/isa/isa.h>

int	comconsole = 0;
int	comautosw = 1;
static	int consinitdone = 0;
static	int comauto;

void
putchar(c)
	int c;
{
	if (!consinitdone)
		cninit();

	if (c == '\n')
		putchar('\r');
	if (comconsole) {
		comcnputc(c);
		if (comauto)
			cgacnputc(c);
	} else
		cgacnputc(c);
}

#ifndef SMALL
int
cngetc()
{

	if (comconsole)
		return (comcngetc());
	else
		return (kbdcngetc());
}

int
cnpoll()
{

	if (comconsole)
		return (comcnpoll());
	else
		return (kbdcnpoll());
}
#endif

/*
 * Initialize console: choose one and initialize.
 * Enable auto switch to com if no keyboard.
 */
cninit()
{

	consinitdone = 1;
	if (comconsole)
		comcninit();
	else if (!kbdcninit() && comautosw) {
		comcninit();
		comconsole = 1;
		comauto = 1;
		printf("keyboard error, auto switch to com console\n");
	}
}
