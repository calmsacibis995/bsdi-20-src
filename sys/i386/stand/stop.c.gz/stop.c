/*
 * Copyright (c) 1991 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI stop.c,v 2.1 1995/02/03 07:49:25 polk Exp
 */

void
_stop(s)
	char *s;
{

	printf("%s\n", s);
	exit(1);
}
