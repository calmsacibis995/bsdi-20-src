/*-
 * Copyright (c) 1994 Berkeley Software Design, Inc.
 * All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *      bioscall.c,v 2.1 1995/02/03 07:47:50 polk Exp
 */

#include <sys/param.h>
#include <i386/stand/bioscall.h>

extern char bios_call_reloc;		/* Where we will be relocated to */
extern char bios_call_start;		/* Where we are relocated from */
extern char bios_call_end;		/* End of code to relocate */

static int bcallcopydone = 0;

#ifndef SMALL
extern void *lidtdata;
extern int lidtsize;
#endif

void 
bios_call(inum, ba)
	int inum;
	struct bios_call *ba;
{

#ifndef SMALL
	if (lidtsize != 0)
		lidt(0, 1024);
#endif

	if (!bcallcopydone) {
		bcopy(&bios_call_start, &bios_call_reloc,
		    &bios_call_end - &bios_call_start);
		bcallcopydone = 1;
	}
	_bios_call(inum, ba);

#ifndef SMALL
	if (lidtsize != 0)
		lidt(lidtdata, lidtsize);
#endif
}
