/*
 * Copyright (c) 1991 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	vgaioctl.h,v 2.1 1995/02/03 07:41:00 polk Exp
 */

#define VGAIOCMAP	_IOWR('G', 5, int)	/* map in framebuffer */
#define VGAIOCUNMAP	_IOW('G', 6, int)	/* unmap framebuffer */
