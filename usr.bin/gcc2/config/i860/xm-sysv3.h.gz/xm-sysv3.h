/* Configuration for GCC for Intel i860 running System V Release 3.  */

#include "i860/xm-i860.h"
#include "xm-svr3.h"
