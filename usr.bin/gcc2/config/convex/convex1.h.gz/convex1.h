/* tm.h file for a Convex C1.  */

#define TARGET_DEFAULT 001

#include "convex/convex.h"
