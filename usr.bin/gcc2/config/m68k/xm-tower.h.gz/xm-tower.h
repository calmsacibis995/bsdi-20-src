#include "m68k/xm-m68k.h"
#include "xm-svr3.h"

#define HAVE_VPRINTF
