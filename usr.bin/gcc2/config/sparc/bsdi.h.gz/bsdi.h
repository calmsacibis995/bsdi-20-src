/*	BSDI bsdi.h,v 2.1 1995/02/03 11:23:10 polk Exp	*/

/* Configuration for a sparc running BSDI 1.1 as the target machine. */

/* Don't assume anything about the header files. */
/* (not actually used on bsdi, but should generally be on anyway) */
#define	NO_IMPLICIT_EXTERN_C

#include "sparc/sparc.h"

#undef CPP_PREDEFINES
#define CPP_PREDEFINES "-Dunix -D__sparc__ -Dsparc -D__bsdi__ -Dbsdi -D__GCC_NEW_VARARGS__ -Asystem(unix) -Asystem(bsd) -Acpu(sparc) -Amachine(sparc)"

#undef LIB_SPEC
#define LIB_SPEC "%{pg:-lc_p}%{!pg:%{p:-lc_p}%{!p:-lc}}"
 
#undef STARTFILE_SPEC
#define	STARTFILE_SPEC "%{pg:gcrt0.o%s}%{!pg:%{p:gcrt0.o%s}%{!p:crt0.o%s}}"

#undef SIZE_TYPE
#define SIZE_TYPE "unsigned int"

#undef WCHAR_TYPE
#define WCHAR_TYPE "int"
#undef WCHAR_TYPE_SIZE
#define WCHAR_TYPE_SIZE 32

/* #undef LINK_SPEC			-- not yet */

/* #define LONG_DOUBLE_TYPE_SIZE 128	-- not yet */

/* turns on `#pragma weak', among others -- not yet tested */
/* #define HANDLE_SYSV_PRAGMA */

/* BSD/OS does have atexit and strerror. */
#define HAVE_ATEXIT
#define	HAVE_STRERROR
