/* This administrivia gets added to the end of limits.h
   if the system has its own version of limits.h.  */

#endif /* not _GCC_LIMITS_H_ */
