/* define if the math lib is to be loaded from a file. */
#undef BC_MATH_FILE
