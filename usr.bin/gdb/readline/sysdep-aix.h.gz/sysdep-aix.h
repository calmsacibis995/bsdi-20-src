/* System-dependent stuff for AIX 3.1 on RS/6000 */

#pragma alloca
#include <sys/types.h>
#include <dirent.h>
typedef struct dirent dirent;
