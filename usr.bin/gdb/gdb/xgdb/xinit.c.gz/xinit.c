/* Do not modify this file.  It is created automatically by "munch". */
void initialize_all_files () {
    {extern void _initialize_blockframe (); _initialize_blockframe ();}
    {extern void _initialize_breakpoint (); _initialize_breakpoint ();}
    {extern void _initialize_stack (); _initialize_stack ();}
    {extern void _initialize_source (); _initialize_source ();}
    {extern void _initialize_values (); _initialize_values ();}
    {extern void _initialize_valprint (); _initialize_valprint ();}
    {extern void _initialize_printcmd (); _initialize_printcmd ();}
    {extern void _initialize_symtab (); _initialize_symtab ();}
    {extern void _initialize_symfile (); _initialize_symfile ();}
    {extern void _initialize_symmisc (); _initialize_symmisc ();}
    {extern void _initialize_infcmd (); _initialize_infcmd ();}
    {extern void _initialize_infrun (); _initialize_infrun ();}
    {extern void _initialize_remote (); _initialize_remote ();}
    {extern void _initialize_command (); _initialize_command ();}
    {extern void _initialize_utils (); _initialize_utils ();}
    {extern void _initialize_copying (); _initialize_copying ();}
    {extern void _initialize_exec (); _initialize_exec ();}
    {extern void _initialize_solib (); _initialize_solib ();}
    {extern void _initialize_signame (); _initialize_signame ();}
    {extern void _initialize_targets (); _initialize_targets ();}
    {extern void _initialize_inftarg (); _initialize_inftarg ();}
    {extern void _initialize_parse (); _initialize_parse ();}
    {extern void _initialize_language (); _initialize_language ();}
    {extern void _initialize_c_exp (); _initialize_c_exp ();}
    {extern void _initialize_m2_exp (); _initialize_m2_exp ();}
    {extern void _initialize_buildsym (); _initialize_buildsym ();}
    {extern void _initialize_dbxread (); _initialize_dbxread ();}
    {extern void _initialize_kernel_core (); _initialize_kernel_core ();}
    {extern void _initialize_sl (); _initialize_sl ();}
    {extern void _initialize_kernel (); _initialize_kernel ();}
    {extern void _initialize_cmdparse (); _initialize_cmdparse ();}
    {extern void _initialize_core (); _initialize_core ();}
    {extern void _initialize_inflow (); _initialize_inflow ();}
    {extern void _initialize_xgdb (); _initialize_xgdb ();}
}
