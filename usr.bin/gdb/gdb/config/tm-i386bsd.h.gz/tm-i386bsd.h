/*	BSDI tm-i386bsd.h,v 2.1 1995/02/03 12:02:34 polk Exp	*/

#define	START_INFERIOR_TRAPS_EXPECTED	2

#include "tm-i386v.h"

#undef	FRAME_NUM_ARGS
#define	FRAME_NUM_ARGS(val, fi)		(val = -1)

#undef	COFF_NO_LONG_FILE_NAMES
#define	NAMES_HAVE_UNDERSCORE		1
#define	NEED_TEXT_START_END		1

extern int stop_stack_dummy;
extern void
i386_pop_dummy_frame PARAMS ((void));
#undef POP_FRAME
#define	POP_FRAME \
	(stop_stack_dummy ? i386_pop_dummy_frame() : i386_pop_frame())

#define	nounderscore			1	/* for cplus_dem.c */

#ifdef KERNELDEBUG
#define	MEM_DEVICE			2

extern int kernel_debugging;
extern int inside_kernel();

#undef FRAME_CHAIN
#define FRAME_CHAIN(thisframe) \
  ((kernel_debugging ? \
      inside_kernel ((thisframe)->pc) : \
      !inside_entry_file ((thisframe)->pc)) ? \
    read_memory_integer ((thisframe)->frame, 4) :\
    0)

#undef FRAME_CHAIN_VALID
#define FRAME_CHAIN_VALID(chain, thisframe) \
	(chain != 0 && \
	 kernel_debugging ? inside_kernstack(chain) : \
		(!inside_entry_file(FRAME_SAVED_PC(thisframe))))

extern int kernel_xfer_memory();
#define	KERNEL_XFER_MEMORY		1

#undef FRAME_SAVED_PC
struct frame_info;
extern CORE_ADDR kernel_translate_saved_pc PARAMS((struct frame_info *));
#define	FRAME_SAVED_PC(FRAME) \
	(!kernel_debugging ? read_memory_integer((FRAME)->frame + 4, 4) : \
	    kernel_translate_saved_pc(FRAME))

#undef FRAME_FIND_SAVED_REGS
extern void kernel_frame_find_saved_regs PARAMS((struct frame_info *,
    struct frame_saved_regs *));
#define	FRAME_FIND_SAVED_REGS(fi, fregs) \
	{ \
		if (kernel_debugging) \
			kernel_frame_find_saved_regs((fi), &(fregs)); \
		else \
			i386_frame_find_saved_regs((fi), &(fregs)); \
	}

#endif
