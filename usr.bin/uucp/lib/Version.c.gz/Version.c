/*
**	Copyright 1992 UUNET Technologies Inc.
**
**	All rights reserved.
**
**	Use of this software is subject to a licence agreement.
*/

/*
**	RCSID Version.c,v 2.1 1995/02/03 13:19:21 polk Exp
**
**	Version.c,v
 * Revision 2.1  1995/02/03  13:19:21  polk
 * Update all revs to 2.1
 *
 * Revision 1.1.1.1  1992/09/28  20:08:42  trent
 * Latest UUCP from ziegast@uunet
 *
 * Revision 1.1  1992/04/14  21:29:38  piers
 * Initial revision
 *
*/

/**		    release #serial date CPU OpSys	**/
#ifndef	VERSION
#define	VERSION		"1.0 #1 92/4/6 CPU OP.SYS.VN"
#endif	/* VERSION */

char	Version[] =	VERSION;
