#!/bin/sh

# uuxqt_hook.sh,v 2.1 1995/02/03 13:16:08 polk Exp

# this will be exec'd by uuxqt whenever it finishes a pass through the
# incoming transaction pool.  since rmail runs sendmail with "-odq", one
# way to get incoming mail to be unbatched is to run (or exec) sendmail
# with "-q" from this file.  if you don't do this, incoming uucp mail will
# wait for the next queue run (see sendmail startup in /etc/{rc,rc.local}
# if you want to know how often that is.)

#exec /usr/sbin/sendmail -q
