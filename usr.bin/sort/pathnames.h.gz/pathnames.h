
/* BSDI $Id:  */

#define		_PATH_STDIN		"/dev/stdin"
#define		_PATH_SORTTMP		"/var/tmp/sort.XXXXXXXX"
