/* libmain - flex run-time support library "main" function */

/* /master/usr.bin/lex/lib/libmain.c,v 2.1 1995/02/03 12:48:17 polk Exp */

extern int yylex();

int main( argc, argv )
int argc;
char *argv[];
	{
	return yylex();
	}
