/* libyywrap - flex run-time support library "yywrap" function */

/* /master/usr.bin/lex/lib/libyywrap.c,v 2.1 1995/02/03 12:48:19 polk Exp */

int yywrap()
	{
	return 1;
	}
