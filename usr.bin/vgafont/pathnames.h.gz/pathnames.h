/* The font directory */
#define _PATH_VGAFONT   "/usr/share/vgafont"

/* The VGA device name */
#define _PATH_VGA       "/dev/vga"
