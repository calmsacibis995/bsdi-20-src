/* tm.h file for a Convex C2.  */

#include "tm-convex.h"

#undef TARGET_DEFAULT
#define TARGET_DEFAULT 2

#define CC1_SPEC "%{mc1:-mnoc2}"

/* Include Posix prototypes unless -traditional. */

#define CPP_SPEC \
"%{mc1:-D__convex_c1__}%{!mc1:-D__convex_c2__}\
 -D__NO_INLINE_MATH\
 %{!traditional:-D__stdc__ -D_POSIX_SOURCE -D_CONVEX_SOURCE}"

/* Search Posix or else backward-compatible libraries depending
   on -traditional. */

#define LIB_SPEC \
"%{mc1:-lC1}%{!mc1:-lC2}\
 %{!p:%{!pg:%{traditional:-lc_old}%{!traditional:-lc}}}\
%{p:%{traditional:-lc_old_p}%{!traditional:-lc_p}}\
%{pg:%{traditional:-lc_old_p}%{!traditional:-lc_p}}"
