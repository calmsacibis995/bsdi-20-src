/*	BSDI pathnames.h,v 2.1 1995/02/03 09:44:25 polk Exp	*/

#define	_PATH_MAGIC	"/usr/share/misc/magic"
