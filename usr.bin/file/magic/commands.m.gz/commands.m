#
# "Commands": stuff for various shells and interpreters.
#
0	string		:\ shell archive or commands for antique kernel text
0	string		#!/bin/sh		Bourne Shell script text
0	string		#!\ /bin/sh		Bourne Shell script text
0	string		#!/bin/csh		C Shell script text
0	string		#!\ /bin/csh		C Shell script text
# korn shell magic, sent by George Wu, gwu@clyde.att.com
0	string		#!/bin/ksh		Korn Shell script text
0	string		#!\ /bin/ksh		Korn Shell script text
0	string	 	#!/bin/tcsh		Tenex C Shell script text
0	string	 	#!\ /bin/tcsh		Tenex C Shell script text
0	string		#!/usr/local/tcsh	Tenex C Shell script text
0	string	 	#!\ /usr/local/tcsh	Tenex C Shell script text
0	string		#!/usr/local/bin/tcsh	Tenex C Shell script text
0	string		#!\ /usr/local/bin/tcsh	Tenex C Shell script text
0	string		#!/bin/awk		Awk Commands text
0	string		#!\ /bin/awk		Awk Commands text
0	string		#!\ /			a
>3	string		>\0			%s script text
0	string		#!/			a
>2	string		>\0			%s script text
0	string		#!\ 			commands text
>3	string		>\0			for %s

# For Larry Wall's perl language.  The ``eval'' line recognizes an
# outrageously clever hack for USG systems.
#				Keith Waclena <keith@cerberus.uchicago.edu>
0	string		#!/bin/perl	perl commands text
0	string		#!\ /bin/perl	perl commands text
0	string		eval\ "exec\ /bin/perl	perl commands text
0       string          #!/usr/bin/perl perl commands text
0       string          #!\ /usr/bin/perl       perl commands text
0       string          eval\ "exec\ /usr/bin/perl      perl commands text
0       string          #!/usr/local/bin/perl   perl commands text
0       string          #!\ /usr/local/bin/perl perl commands text
0       string          eval\ "exec\ /usr/local/bin/perl        perl commands text
