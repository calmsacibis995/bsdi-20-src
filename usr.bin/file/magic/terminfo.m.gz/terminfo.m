#
# Terminfo
#
# XXX - byte order for screen images?
#
0	string		\032\001	Compiled terminfo entry
0	short		0433		Curses screen image
0	short		0434		Curses screen image
