0	string		begin 		uuencoded mail text
# Btoa(1) is an alternative to uuencode that requires less space.
0	string		xbtoa\ Begin	btoa'd text
