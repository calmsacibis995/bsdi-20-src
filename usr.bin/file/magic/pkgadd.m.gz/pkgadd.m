#
# SysV R4 PKG Datastreams:
#
0       string          #\ PaCkAgE\ DaTaStReAm  pkg Datastream (SVR4)
