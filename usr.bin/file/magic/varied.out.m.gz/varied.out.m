#	Herewith many of the object file formats used by USG systems.
#	Most have been moved to files for a particular processor,
#	and deleted if they duplicate other entries.
#
0	short		0610		Perkin-Elmer executable
