#
# magic.postscript: Magic for postscript files
#
# XXX - should we match only versions 1.0 and 2.0, or should we wildcard
# it?
#
0	string		%!		PostScript document
>2	string	PS-Adobe-		conforming
>>11	string	1.0			at level %s
>>11	string	2.0			at level %s
>>11	string	3.0			at level %s
# Some pc's have the annoying habit of adding a ^D
0	string		\004%!		PostScript document
>3	string	PS-Adobe-		conforming
>>12	string	1.0			at level %s
>>12	string	2.0			at level %s
>>12	string	3.0			at level %s
