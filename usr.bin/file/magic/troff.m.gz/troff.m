#
# magic.troff:
#
0	string		\100\357	very old (C/A/T) troff output data
0	string		'		[nt]roff, tbl, or eqn input text

