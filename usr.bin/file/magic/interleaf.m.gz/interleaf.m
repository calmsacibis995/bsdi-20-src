#
# magic for InterLeaf TPS:
0	string		=\210OPS	Interleaf saved data
0	string		=<!OPS		Interleaf document text
>5	string		,\ Version\ 	(version
>>14	string		>\0		%s)

