# A collection of various "ar" and "cpio" archive formats.
# "Tar" archives are handled in the C code.
0	short		070707		cpio archive
0	string		070707		ASCII cpio archive
0	long		0177555		very old archive
0	short		0177555		very old PDP-11 archive
0	long		0177545		old archive
0	short		0177545		old PDP-11 archive
0	long		0100554		apl workspace
0	string		=<ar>		archive
0	string		!<arch>		archive
>8	string		__.SYMDEF	random library
0	string		-h-		Software Tools format archive text
# Rahul Dhesi's zoo archive format, from keith@cerberus.uchicago.edu.
20	long		0xdca7c4fd	Rahul Dhesi's "zoo" archive
