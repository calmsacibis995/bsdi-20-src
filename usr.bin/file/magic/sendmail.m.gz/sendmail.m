#
# magic.sendmail:
#
# XXX - byte order?
#
0	byte	046	  Sendmail frozen configuration 
>16	string	>\0	  - version %s
0	short	0x271c	  Sendmail frozen configuration
>16	string	>\0	  - version %s
