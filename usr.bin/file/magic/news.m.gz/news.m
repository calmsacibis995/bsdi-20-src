# NeWS, not "news" as in "netnews"
0	string		StartFontMetrics	ASCII font metrics
0	string		StartFont	ASCII font bits
0	long		0x137A2944	NeWS bitmap font
0	long		0x137A2947	NeWS font family
