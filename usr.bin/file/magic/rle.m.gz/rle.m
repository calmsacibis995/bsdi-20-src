# From <janl@ifi.uio.no>
# I made this with the help of the man page for rle(5). Ihey missing
# from the magic numbers I have:

#
# rle
#
0       short           0xcc52          Utah Raster Toolkit RLE
>2      short           >0              lower left corner: %d
>4      short           >0              lower right corner: %d
>6      short           >0              %d x
>8      short           >0              %d
>10     byte&0x1        =0x1            CLEARFIRST
>10     byte&0x2        =0x2            NO_BACKGROUND
>10     byte&0x4        =0x4            ALPHA
>10     byte&0x8        =0x8            COMMENT
>11     byte            >0              %d colour channels
>12     byte            >0              %d bits pr. pixel
>13     byte            >0              %d colour map channels
