#
# Various MS-DOS magic numbers
#
0	string		MZ		DOS executable (EXE)
0	string		LZ		DOS executable (built-in)
0	byte		0xe9		DOS executable (COM)
0	byte		0xeb		DOS executable (COM)
0	byte		0xf0		MS-DOS program library
