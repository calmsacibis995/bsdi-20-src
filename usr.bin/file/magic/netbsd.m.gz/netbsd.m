#
# All new-style magic numbers are in network byte order.
#
0	belong&077777777	041400413	netbsd/i386 demand paged
>0	byte			&0x80
>>20	belong			<4096		shared library
>>20	belong			=4096		dynamically linked executable
>>20	belong			>4096		dynamically linked executable
>0	byte			^0x80		executable
>16	belong			>0		not stripped
