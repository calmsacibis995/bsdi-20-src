0	string	\001\001\001\001	MMDF mailbox
