0	string	FONT	ASCII vfont text
0	short	0436	Berkeley vfont data
0	short	017001	byte-swapped Berkeley vfont data
