#
# magic.ps: psdatabase magic
#
0	belong&0xff00ffff	0x56000000	ps database
>1	string	>\0	version %s
>4	string	>\0	from kernel %s
