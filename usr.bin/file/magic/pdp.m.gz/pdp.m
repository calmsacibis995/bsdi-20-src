#
# magic.pdp: PDP-11 executable/object and APL workspace
#
0	lelong		0101555		PDP-11 single precision APL workspace
0	lelong		0101554		PDP-11 double precision APL workspace

#
# PDP-11 a.out
#
0	leshort		0407		PDP-11 executable
>8	leshort		>0		not stripped

0	leshort		0401		PDP-11 UNIX/RT ldp
0	leshort		0405		PDP-11 old overlay

0	leshort		0410		PDP-11 pure executable
>8	leshort		>0		not stripped

0	leshort		0411		PDP-11 separate I&D executable
>8	leshort		>0		not stripped

0	leshort		0437		PDP-11 kernel overlay
