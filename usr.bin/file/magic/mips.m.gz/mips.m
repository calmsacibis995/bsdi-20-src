#
# RISC MIPS decstation
# Should this be "leshort", given that DEC ran the DECstations in
# little-endian mode?
#
# Where is the non-SGI, non-DEC MIPS stuff?
#
0	short		0x6201		MIPS executable
