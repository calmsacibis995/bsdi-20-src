# From <rob@pe1chl.ampr.org>
# These are the /etc/magic entries to decode datafiles as used for the
# ZyXEL U-1496E DATA/FAX/VOICE modems.  (This header conforms to a
# ZyXEL-defined standard)

0       string          ZyXEL\002       ZyXEL voice data
>10     byte            0               - CELP encoding
>10     byte            1               - ADPCM2 encoding
>10     byte            2               - ADPCM3 encoding
