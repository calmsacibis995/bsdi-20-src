#
# Apple II file formats
#
0	string		FiLeStArTfIlEsTaRt	binscii (apple ][) text
0	string		\x0aGL			Binary II (apple ][) data
0	string		\x76\xff		Squeezed (apple ][) data
0	string		SIT!			StuffIt (macintosh) text
0	string		NuFile			NuFile archive (apple ][) data
0	string		N\xf5F\xe9l\xe5		NuFile archive (apple ][) data

