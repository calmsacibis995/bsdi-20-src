#
# Zilog Z8000.
#
# Was it big-endian or little-endian?  My Product Specification doesn't
# say.
#
0	long		0xe807		object file (z8000 a.out)
0	long		0xe808		pure object file (z8000 a.out)
0	long		0xe809		separate object file (z8000 a.out)
0	long		0xe805		overlay object file (z8000 a.out)

