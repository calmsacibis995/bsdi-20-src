#
# XXX - byte order?
#
0	short	0x2a17	"compact bitmap" format (Poskanzer)
