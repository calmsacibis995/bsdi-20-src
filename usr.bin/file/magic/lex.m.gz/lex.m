#	derived empirically, your offsets may vary!
53	string		yyprevious	c program text (from lex)
>3	string		>\0		 for %s
