#
# magic.lif:
#
# XXX - byte order?
#
0	short		0x8000		lif file
