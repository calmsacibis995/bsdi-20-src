# =Id: sgml,v 1.3 1993/01/05 12:52:44 ian Exp =
# SGML goop, mostly from rph@sq.
0	string		\<!DOCTYPE	Exported SGML document
0	string		\<!doctype	Exported SGML document
0	string		\<!SUBDOC	Exported SGML subdocument
0	string		\<!subdoc	Exported SGML subdocument
