#
# magic.x11
#
# I think this is byte-order-dependent; if so, it should become:
#
# 0	belong	00000004	X11 big-endian snf font
# 0	lelong	00000004	X11 little-endian snf font
#
0	long	00000004	X11 snf font
