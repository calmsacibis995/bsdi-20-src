#	BSDI Localstuff.m,v 2.1 1995/02/03 09:44:53 polk Exp
# =Id: Localstuff,v 1.2 1993/01/05 13:22:25 ian Exp =
# Add any locally-observed files here.  Remember:
# text if readable, executable if runnable binary, data if unreadable.

0	lelong		0314		386 compact demand paged pure executable
>16	lelong		>0		not stripped
>32	byte		0x6a		(uses shared libs)

0	lelong		0407		386 executable
>16	lelong		>0		not stripped
>32	byte		0x6a		(uses shared libs)

0	lelong		0410		386 pure executable
>16	lelong		>0		not stripped
>32	byte		0x6a		(uses shared libs)

0	lelong		0413		386 demand paged pure executable
>16	lelong		>0		not stripped
>32	byte		0x6a		(uses shared libs)
