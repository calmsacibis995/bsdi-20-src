# Unfortunately, saved netnews also has From line added in some news software.
#0	string		From 		mail text
# There are tests to ascmagic.c to cope with mail and news.
0	string		Relay-Version: 	old news text
0	string		#!\ rnews	batched news text
0	string		N#!\ rnews	mailed, batched news text
0	string		Forward\ to 	mail forwarding text
0	string		Pipe\ to 	mail piping text
0	string		Return-Path:	smtp mail text
0	string		Path:		news text
0	string		Xref:		news text
0	string		From:		news or mail text
0	string		Article 	saved news text
