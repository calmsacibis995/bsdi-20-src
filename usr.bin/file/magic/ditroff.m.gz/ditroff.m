# Magic numbers for ditroff intermediate language
0	string		x\ T\ cat	titroff output for the C/A/T text
0	string		x\ T\ ps	titroff output for PostScript
0	string		x\ T 		titroff output text
