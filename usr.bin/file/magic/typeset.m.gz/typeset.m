# other typesetting magic
0	string		\100\357	very old (C/A/T) troff output data
0	string		Interpress/Xerox	Xerox InterPress data
>16	string		/			(version
>>17	string		>\0			%s)
