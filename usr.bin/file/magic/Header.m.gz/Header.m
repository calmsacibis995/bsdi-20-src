#! file
# Magic data for file(1) command.
# Machine-genererated from src/cmd/file/magdir/*; edit there only!
# Format is described in magic(files), where:
# files is 4 on V7 and BSD, 4 on SV, and ?? in the SVID.
