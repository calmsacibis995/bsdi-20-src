0	string		#\ Magic	magic text file for file(1) cmd
