#
# XXX - what byte order does a Convex use?
#
0	long		0513		Convex executable
