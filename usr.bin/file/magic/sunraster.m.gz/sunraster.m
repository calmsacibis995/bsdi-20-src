#
# Sun rasterfiles
#
# XXX - byte order?  What about the 386i?
#
0	string	\x59\xa6\x6a\x95	rasterfile
>4	belong	>0		%d
>8	belong	>0		x %d
>12	belong	>0		x %d
>20	belong	0		old format
>20	belong	2		compressed
>24	belong	1		with color map
