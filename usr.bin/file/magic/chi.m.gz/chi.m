# ChiWriter files
0       string          \\1cw\          ChiWriter file
>5      string          >\0             version %s
0       string          \\1cw           ChiWriter file
