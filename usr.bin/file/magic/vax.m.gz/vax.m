#
# magic.pdp: VAX executable/object and APL workspace
#
0	lelong		0101557		VAX single precision APL workspace
0	lelong		0101556		VAX double precision APL workspace

#
# VAX a.out (32V, BSD)
#
0	lelong		0407		VAX executable
>16	lelong		>0		not stripped

0	lelong		0410		VAX pure executable
>16	lelong		>0		not stripped

0	lelong		0413		VAX demand paged pure executable
>16	lelong		>0		not stripped

0	lelong		0420		VAX demand paged (first page unmapped) pure executable
>16	lelong		>0		not stripped

#
# VAX COFF
#
# The `versions' should be un-commented if they work for you.
# (Was the problem just one of endianness?)
#
0	leshort		0570		VAX COFF executable
>12	lelong		>0		not stripped
>22	leshort		>0		- version %ld
0	leshort		0575		VAX COFF pure executable
>12	lelong		>0		not stripped
>22	leshort		>0		- version %ld
