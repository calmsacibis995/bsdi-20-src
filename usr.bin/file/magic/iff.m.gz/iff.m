# image file format
# From Robert Potter, potter@cs.rochester.edu
0	string		Imagefile\ version-	iff image data
# this adds the whole header (inc. version number), informative but longish
>10	string		>\0		%s
