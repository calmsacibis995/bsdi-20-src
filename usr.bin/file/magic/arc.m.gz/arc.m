0	byte		26		'arc' archive
>1	byte		0		(empty)
>1	byte		1		(old format)
