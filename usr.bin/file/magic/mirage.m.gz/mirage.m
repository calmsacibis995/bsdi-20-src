#
# XXX - byte order?
#
0	long	31415		Mirage Assembler m.out executable
