#
# magic.apl:
#
0	long		0100554		APL workspace (Ken's original?)
