0	string	\366\366\366\366	Formatted floppy w/ no filesystem data
