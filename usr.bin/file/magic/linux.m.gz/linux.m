# Values for Linux/i386 binaries, From: Rik Faith <faith@cs.unc.edu>
2       leshort         100             Linux/i386
>0      leshort         0407            executable
>0      leshort         0410            pure executable
>0      leshort         0413            demand paged executable
>16     lelong          >0              not stripped
>0      string          Jump            jump
# core dump file
216     lelong          0421            core file (Linux)
