#
# magic file lines for output from "diff"...
0	string		diff\ 	'diff' output text
0	string		***\ 		'diff' output text
0	string		Only\ in\ 	'diff' output text
0	string		Common\ subdirectories:\ 	'diff' output text
