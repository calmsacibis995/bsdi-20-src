#
# Motorola
#
# 68K
#
0	beshort		0520		mc68k COFF
>18	beshort		^00000020	object
>18	beshort		&00000020	executable
>12	belong		>0		not stripped
>168	string		.lowmem		Apple toolbox
>20	beshort		0407		(impure)
>20	beshort		0410		(pure)
>20	beshort		0413		(demand paged)
>20	beshort		0421		(standalone)
0	beshort		0521		mc68k executable (shared)
>12	belong		>0		not stripped
0	beshort		0522		mc68k executable (shared demand paged)
>12	belong		>0		not stripped
#
# Motorola/UniSoft 68K Binary Compatibility Standard (BCS)
#
0	beshort		0554		68K BCS executable
#
# 88K
#
# Motorola/88Open BCS
#
0	beshort		0555		88K BCS executable
