#
# pgp (pretty good protection)
0       beshort         0x9900                  pgp key public ring
0       beshort         0x9501                  pgp key security ring
0       beshort         0x9500                  pgp key security ring
0       string          -----BEGIN\040PGP       pgp armored data
>15     string          PUBLIC\040KEY\040BLOCK- public key blocK
>15     string          MESSAGE-                message
>15     string          SIGNED\040MESSAGE-      signed message
>15     string          PGP\040SIGNATURE-       signature
