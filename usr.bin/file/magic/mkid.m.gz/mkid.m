#
# ID is the binary tags database produced by mkid(1).
#
# XXX - byte order?
#
0	string		\311\304	ID tags data
>2	short		>0		version %d
