#
# Various flavors of x86 UNIX executable/object (other than Xenix, which
# is in "microsoft").  DOS is in "ms-dos"; the ambitious soul can do
# Windows as well.
#
# Windows NT belongs elsewhere, as you need x86 and MIPS and Alpha and
# whatever comes next (HP-PA Hummingbird?).  OS/2 may also go elsewhere
# as well, if, as, and when IBM makes it portable.
#
# The `versions' should be un-commented if they work for you.
# (Was the problem just one of endianness?)
#
0	leshort		0502		basic-16 executable
>12	lelong		>0		not stripped
#>22	leshort		>0		- version %ld
0	leshort		0503		basic-16 executable (TV)
>12	lelong		>0		not stripped
#>22	leshort		>0		- version %ld
0	leshort		0510		x86 executable
>12	lelong		>0		not stripped
0	leshort		0511		x86 executable (TV)
>12	lelong		>0		not stripped
0	leshort		=0512		iAPX 286 executable small model (COFF)
>12	lelong		>0		not stripped
#>22	leshort		>0		- version %ld
0	leshort		=0522		iAPX 286 executable large model (COFF)
>12	lelong		>0		not stripped
#>22	leshort		>0		- version %ld
0	leshort		=0514		80386 COFF executable
>12	lelong		>0		not stripped
>22	leshort		>0		- version %ld
