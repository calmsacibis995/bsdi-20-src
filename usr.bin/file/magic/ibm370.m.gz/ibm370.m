#
# IBM 370 and compatibles.
#
# "ibm370" said that 0x15d == 0535 was "ibm 370 pure executable".
# What the heck *is* "USS/370"?
#
0       beshort		0531		SVR2 executable (Amdahl-UTS)
>12	belong		>0		not stripped
>24     belong		>0		- version %ld
0	beshort		0534		SVR2 pure executable (Amdahl-UTS)
>12	belong		>0		not stripped
>24	belong		>0		- version %ld
0	beshort		0530		SVR2 pure executable (USS/370)
>12	belong		>0		not stripped
>24	belong		>0		- version %ld
0	beshort		0535		SVR2 executable (USS/370)
>12	belong		>0		not stripped
>24	belong		>0		- version %ld

