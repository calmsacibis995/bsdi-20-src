0       string          \037\213        gzip compressed data
>2      byte            <8              - reserved method
>2      byte            8               - deflate method
>3	byte		&0x01		, ascii
>3	byte		&0x02		, continuation 
>3	byte		&0x04		, extra field
>3	byte		&0x08		, original file name
>3	byte		&0x10		, comment
>3	byte		&0x20		, encrypted
>4	ledate		x		, last modified: %s
>8	byte		2		, max compression
>8	byte		4		, max speed
>9	byte		=0x00		os: MS/DOS
>9	byte		=0x01		os: Amiga
>9	byte		=0x02		os: VMS
>9	byte		=0x03		os: Unix
>9	byte		=0x05		os: Atari
>9	byte		=0x06		os: OS/2
>9	byte		=0x07		os: MacOS
>9	byte		=0x0A		os: Tops/20
>9	byte		=0x0B		os: Win/32
