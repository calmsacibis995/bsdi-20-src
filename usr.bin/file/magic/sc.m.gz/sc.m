# for SC
38	string		Spreadsheet	sc file
