#
# Magic number for FrameMaker files
# This stuff came on a FrameMaker demo tape, most of which is
# copyright, but this file is "published" as witness the following:
#
0	string		\<MakerFile	FrameMaker document
>11	string		3.0		 (3.0
>11	string		2.0		 (2.0
>11	string		1.0		 (1.0
>14	byte		x		  %c)
0	string		\<MIFFile	FrameMaker MIF file
>9	string		3.0		 (3.0)
>9	string		2.0		 (2.0)
>9	string		1.0		 (1.x)
0	string		\<MakerDictionary	FraneMaker Dictionary text
>17	string		3.0		 (3.0)
>17	string		2.0		 (2.0)
>17	string		1.0		 (1.x)
0	string		\<MakerScreenFon	FrameMaker Font file
>17	string		1.01		 (%s)
0	string		\<MML		FrameMaker MML file
0	string		\<Book		FrameMaker Book file
>10	string		3.0		 (3.0
>10	string		2.0		 (2.0
>10	string		1.0		 (1.0
>13	byte		x		  %c)
0	string		\<Maker Intermediate Print File	FrameMaker IPL file
0	string		\<MakerDictionary	FraneMaker Dictionary text
