#
# magic.pyramid: Magic for pyramids
#
# XXX - byte order?
#
0	long		0x50900107	Pyramid 90x family executable
0	long		0x50900108	Pyramid 90x family pure executable
>16	long		>0		not stripped
0	long		0x5090010b	Pyramid 90x family demand paged pure executable
>16	long		>0		not stripped
