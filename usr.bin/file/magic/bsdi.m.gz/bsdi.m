# BSDI BSD/386
0	long	0314	BSD/386 demand paged (first page unmapped) pure executable
