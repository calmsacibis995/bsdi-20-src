/*	BSDI	defs.h,v 2.1 1995/02/03 12:35:25 polk Exp	*/

#define PROG_PREFIX		"" 
#define DEVICE			"ps"
#define FONTPATH		"/usr/local/lib/groff_font:/usr/share/groff_font"
#define MACROPATH		"/usr/local/lib/tmac:/usr/share/tmac"
#define INDEX_SUFFIX		".i"
#define COMMON_WORDS_FILE	"/usr/share/groff_font/eign"
#define DEFAULT_INDEX_DIR	"/usr/share/dict/papers"
#define DEFAULT_INDEX_NAME	"Ind"
#define DEFAULT_INDEX		"/usr/share/dict/papers/Ind"
