/*-
 * Copyright (c) 1992,1993 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 */
/*	Krystal AsyncIO.h,v 2.1 1995/02/03 09:39:49 polk Exp */
#if defined(__cplusplus)
extern "C" {
#endif
void	_RegisterIO(int, void (*)(void *), void *, void (*)());
void	_AssociateIO(int, int);
void	_DeAssociateIO(int, int);
void	_LockIO(int);
int	_UnlockIO(int);
int	_LevelIO(int);
int	_DetachIO(int);
int	_EndIO(int, int);
void	_BlockIO(void);
void	_UnblockIO(void);
#if defined(__cplusplus)
}
#endif

#define	_Un_RegisterIO(x) _RegisterIO((x), (void (*))0, (void *)0, (void (*))0)
