/*	Krystal config.h,v 2.1 1995/02/03 09:40:15 polk Exp */
/* various overall defines used in config.c and others */

#include <errno.h>

#define MAXPORT		0x400

#define N_PARALS_MAX	3
#define N_COMS_MAX	4	/* DOS restriction (sigh) */

extern char *xfont;

void setver(char *, short);
short getver(char *);
