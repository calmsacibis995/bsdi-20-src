/*-
 * Copyright (c) 1992,1993 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 */
/*	Krystal crt0.c,v 2.1 1995/02/03 09:40:17 polk Exp */
char **environ;
char *__progname;

start(int argc, char **argv, char **env)
{
	environ = env;
	__progname = *argv;
	quit(main(argc, argv, environ));
}
