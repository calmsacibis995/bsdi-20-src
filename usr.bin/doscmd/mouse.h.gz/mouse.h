typedef struct {
	u_short		hardcursor:1;
	u_short		installed:1;
	u_short		cursor:1;
	u_short		show:1;
	u_short		buttons:3;

	u_short		init;
    	u_short		start;
    	u_short		end;
	u_short		hmickey;
	u_short		vmickey;
	u_short		doubling;
	u_long		handler;
    	u_short		mask;
	u_long		althandler[3];
    	u_short		altmask[3];
    	struct {
	    u_short	x;
	    u_short	y;
	    u_short	w;
	    u_short	h;
    	}		range,
			exclude;
	u_short		x;
	u_short		y;
	u_short		lastx;
	u_short		lasty;

    	u_short		downs[3];
    	u_short		ups[3];
} mouse_t;

extern mouse_t mouse_status;
extern u_char *mouse_area;
