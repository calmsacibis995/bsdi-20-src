/*	BSDI ppp.c,v 2.1 1995/02/03 12:56:40 polk Exp	*/

/*
 * Establish a PPP connection
 *
 * ppp  - attach dial-in connection if called as a login shell
 * ppp -d [systemid]
 *      - dial-out dodaemon mode (calls on dropped packets)
 * ppp systemid
 *      - call the specified system explicitly
 *
 * Additional parameters:
 *      -s sysfile      - use sysfile instead of /etc/ppp.sys
 *      -x              - turn on debugging
 *      -b              - put self in background after connecting
 *
 * /etc/ppp.sys contains termcap-style records:
 *      at      (str) Auto call unit type.
 *      br      (num) Baud rate.
 *      cm      (str) Map of special characters (as in pppconfig)
 *      cu      (str) Call unit if making a phone call.
 *      di      (bool) Dial-in allowed.
 *      do      (bool) Automatic dial-out allowed.
 *      dt      (num) Dial timeout (in seconds).
 *      du      (bool) This is a dial-up line
 *      dv      (str) Device(s) to open to establish a
 *                    connection.
 *      e0-e9   (str) String to wait for on nth step of logging in
 *                    (after sending s0-s9)
 *      f0-f9   (str) Strings to send if failed to get an expected
 *                    string (e0-e9)
 *      id      (num) Disconnect on idle (n seconds)
 *      if      (str) Space-separated list of ifconfig parameters.
 *      im      (bool) Immediate Connection
 *      in      (num) Interface number.
 *	ku	(bool) Do not mark interface as down when leaving
 *	ld	(str) Script to run when link goes down.
 *	li	(str) Script to run system logs in.
 *	lu	(str) Script to run when link comes up.
 *      mc      (num) Max PPP config retries.
 *      mr      (num) PPP MRU.
 *      ms      (str) Stty-style terminal setup string.
 *      mt      (num) Max PPP terminate retries.
 *      pf      (str) Comma-separated list of PPP flags (as in pppconfig)
 *      pn      (str) Telephone number(s) for this host.
 *      s0-s9   (str) String to send on nth step of logging in.
 *      t0-t9   (num) Timeout in seconds for e0-e9
 *      tc      (str) Cap. list continuation.
 *      to      (num) PPP retrty timeout (1/10 sec).
 *	wt	(num) Wait timeout for certain operations (such as BOS)
 */

#include "ppp.h"

#include <sys/param.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/signal.h>

#include <net/if.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/pppioctl.h>

#include <string.h>

#include <sys/wait.h>
#include <stdarg.h>
#include <setjmp.h>

void wt_alarm();
void cleanup(int);
int execute(char *, ...);

int background = 0;
int debug = 0;
int dodaemon = 0;
char *sysfile = _PATH_SYS;
char *sysname;
jmp_buf wt_env;

char ifname[30];

int Socket;
int amup = 0;
int quiet;

static int busymsg = 0;
static uid_t suid = -1;
static gid_t sgid = -1;

main(ac, av)
	int ac;
	char **av;
{
	extern int optind;
	extern char *optarg;
	extern char *getlogin();
	int dialin = 0;
	char *linkname;
	int i, timo;
	int ld, oldld;
	char *reason;
	pid_t pid;
	int rv;
	void (*osig)();


	for (;;) {
		switch (getopt(ac, av, "bdqxs:")) {
		default:
		usage:
			errx(1, "usage: ppp [-s sysfile] [-b] [-d] [-x] [systemname]");
		case 'b':
			background++;
			continue;

		case 'd':
			dodaemon++;
			continue;

		case 'x':
			debug++;
			continue;

		case 'q':
			quiet = 1;
			continue;

		case 's':
			suid = getuid();
			sgid = getgid();
			sysfile = optarg;
			continue;

		case EOF:
			break;
		}
		break;
	}

	if (optind < ac - 1)
		goto usage;

	/* Check permissions */
	if ((dodaemon || debug) && getuid() != 0) {
		if (dodaemon)
			warnx("only superuser can run in dodaemon mode");
		if (debug)
			warnx("only superuser can debug");
		exit(1);
	}

	setbuf(stdout, NULL);

	/* Get the system name */
	if (ac > optind)
		sysname = av[optind];
	else if (dodaemon)
		sysname = 0;
	else {
		sysname = getlogin();
		dialin++;
		if (sysname == 0)
			errx(1, "can't get the login name");
		/*
		 * Standard dial in lines must run their scripts
		 * as root.
		 */
    	    	if (suid == -1)
			suid = geteuid();
	}

	/*
	 * Daemon mode... look out for the dropped packets!
	 */
	if (dodaemon && sysname == 0)
		/*
		 * Scan the system file for all automatic dial-outs
		 * and do forks for every system name.
		 */
		errx(1, "dodaemon w/o sysname IS NOT IMPLEMENTED (yet)");

	getsyscap(sysname, sysfile);

    	if (WT == -1)
		WT = WAITTIMEOUT;

	if (quiet)
		tipset_verbose(0);
	tipset_dialtimeout(DT);

	if (dialin && DI == 0)
		errx(1, "dial in is not allowed for %s", sysname);
	if (!dialin && DO == 0)
		errx(1, "dial out is not allowed for %s", sysname);

	/*
	 * Get a socket for ifreqs
	 */
	Socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (Socket < 0)
		ifperror("socket", "AF_INET");

	if (IN == -1) {
		if (IF == 0 && LI == 0)
			errx(1, "%s \"li\" or \"if\" required for dynamic interface assignment",
				sysname);
		if (!dialin && IM == 0)
			errx(1, "%s: Dynamic interface allocation is not supported\n\ton demand dial connections.", sysname);
		/* We will allocate the interface below */
	} else
		/* Hardcoded interface name: required for waitdrop() */
		snprintf(ifname, sizeof ifname, "ppp%d", IN);

	/* Dial-in? Just set the line discipline and wait */
daemon_loop:
	if (dialin) {
		log("dialin: %s\n", sysname);
		FD = 0;

		/* Set working line parameters */
		set_lparms(FD);
		goto start_protocol;
	}

	/*
	 * Wait for a dropped packet at the interface
	 */
	if (dodaemon) {
#if 0
		if (DO == 0)
			errx(1, "dodaemon mode is not allowed for %s",
				sysname);
#endif
		if (IM == 0) {
			ifconfig(ifname, IF, IFF_UP);
			waitdrop(ifname);
		}
	}

	/*
	 * Hunt for an available device
	 */
	(void) signal(SIGHUP, cleanup);
	(void) signal(SIGINT, cleanup);
	(void) signal(SIGTERM, cleanup);

	if ((linkname = hunt()) == 0) {
		if (busymsg++ == 0)
			log("%s: all ports busy\n", sysname);
		if (dodaemon) {
			if (debug)
				printf("All ports busy...\n");
			sleep(60);
			goto daemon_loop;
		}
		errx(1, "all ports busy");
	}
    	log("dialing on %s\n", linkname);
	busymsg = 0;
	if (debug)
		printf("Dialing on %s...\n", linkname);

	/*
	 * Dial out
	 */
	reason = Connect(linkname);
	if (reason) {
		close(FD);
		(void) uu_unlock(uucplock);
		log("%s: %s (%s)\n", sysname, reason, linkname);
		if (dodaemon)
			goto daemon_loop;
		errx(1, "%s (%s)", reason, linkname);
	}
	set_lparms(FD);

	/*
	 * Do all the log sequence
	 */
	if (debug)
		printf("\nLog in...\n");
	for (i = 0; i < 10; i++) {
		if (S[i] != 0) {
			if (debug)
				printf("Send: <%s>\n", printable(S[i]));
			write(FD, S[i], strlen(S[i]));
		}
		timo = T[i];
		if (timo == -1) {
			if (E[i] == 0)
				continue;
			timo = 15;
		}
		if (E[i] == 0)
			sleep(timo);
		else if (expect(FD, E[i], timo)) {
			if (F[i] != 0) {
				if (debug)
					printf("Send F: <%s>\n", printable(F[i]));
				write(FD, F[i], strlen(F[i]));
				if (!expect(FD, E[i], timo))
					continue;
			}
			close(FD);
			(void) uu_unlock(uucplock);
			log("%s: login failure (%s, expected %s)\n",
				sysname, linkname, printable(E[i]));
			if (dodaemon)
				goto daemon_loop;
			errx(1, "login failed (expected %s)", printable(E[i]));
		}
	}

	/*
	 * Get old line discipline
	 */
	oldld = 0;      /* default... */
	(void) ioctl(FD, TIOCGETD, &oldld);

	if (debug)
		printf("Set PPP line disc.\n");

	/*
	 * Set PPP line discipline
	 */
start_protocol:
	ld = PPPDISC;
	if (ioctl(FD, TIOCSETD, &ld) < 0) {
		(void) uu_unlock(uucplock);
		err(1, "%s: ioctl(TIOCSETD)", linkname);
	}

	if (ioctl(FD, PPPIOCSUNIT, &IN) < 0) {
		switch (errno) {
		case ENXIO:
			warnx("no interface");
			break;
		case EBUSY:
			warnx("interface is busy");
			break;
		default:
			warn("%s: ioctl(PPPIOCSUNIT)", linkname);
			break;
		}
		(void) uu_unlock(uucplock);

		if (DI && dodaemon)
			goto daemon_loop;
		else
			exit(1);
	}

	/*
	 * At this point the following should be true:
	 *   1) We know the interface number.
	 *   2) PPP line discipline is set.
	 *
	 * If this is a dialup connection now is the time to set the address
	 * on the interface in case the other end wants us to do the
	 * IP address assignment.  So we would like the interface to be
	 * down at this point -- I'm not sure that that will be true.
	 */

	snprintf(ifname, sizeof ifname, "ppp%d", IN);
	
	if (LI != 0)
		loginscript(LI);

	/*
	 * Load interface and PPP parameters
	 */
	ifconfig(ifname, IF, IFF_UP);
	pppconfig(ifname);

#ifdef PPPIOCIPWBOS
	/*
	 * Wait for IPCP come up.  Needs to happen after interface goes up.
	 */
    	if (setjmp(wt_env) == 0) {
		osig = signal(SIGALRM, wt_alarm);
		alarm(WT);
		waittlu(ifname);
		alarm(0);
		signal(SIGALRM, osig);
	} else {
		alarm(0);
		signal(SIGALRM, osig);
		warnx("PPPIOCIPWBOS timed out");
		log("%s: PPPIOCIPWBOS timed out on %s", sysname, ifname);
#ifdef notyet
		/*
		 * We probably should timeout the connnection in  this
		 * case, but there are many issues that need to be delt
		 * with, such as undoing the login script.  This is too
		 * much change before 2.0 ships, so for now we just pretend
		 * that it worked (as we used to do) but at least the
		 * situation has been logged.
		 */
		goto timeout;
#endif
    	}
#else
#error	You should have PPPIOCIPWBOS defined
	sleep(15);	/* XXX */
#endif

	log("%s: connected on %s\n", sysname, ifname);

	/*
	 * Run link up script.
	 */
    	amup = 1;
	if (LU != 0)
		linkscript(LU);

	/*
	 * End of session
	 */
	if (background) {
		switch (pid = fork()) {
		case -1:
			warnx("couldn't fork");
			log("%s: couldn't fork\n", sysname);
			break;
		default:
			exit(0);			/* Parent exits. */
		case 0:
			/*
			 * Child continues in background.
			 */
			if (debug)
				printf("Continue in background.\n");
			setsid();
			chdir("/");
			break;
		}
	}
	if (debug)
		printf("Wait for End Of Session...\n");
	(void) ioctl(FD, PPPIOCWEOS);
	if (debug)
		printf("Restore & close line\n");
	(void) ioctl(FD, TIOCSETD, &oldld);
	close(FD);      				/* hang up! */
	(void) uu_unlock(uucplock);
	log("%s: end of session\n", sysname);

	/*
	 * Run link down script.
	 */
	if (LD != 0)
		linkscript(LD);

	amup = 0;

timeout:
	if (dodaemon)
		goto daemon_loop;

    	if (KU == 0)
		ifconfig(ifname, IF, 0);

	exit(0);
}

static expect_interrupted;

/* Timeout signal handler */
static void
expalarm()
{
	expect_interrupted = 1;
}


/*
 * Look up for an expected string or until the timeout is expired
 * Returns 0 if successfull.
 */
int
expect(fd, str, timo)
	int fd;
	char *str;
	int timo;
{
	struct sigaction act, oact;
	char buf[128];
	char nchars, expchars;
	char c;

	if (debug)
		printf("Expect <%s> (%d sec)\nGot: <", printable(str), timo);
	nchars = 0;
	expchars = strlen(str);
	expect_interrupted = 0;
	act.sa_handler = expalarm;
	act.sa_mask = 0;
	act.sa_flags = 0;
	sigaction(SIGALRM, &act, &oact);
	alarm(timo);

	do {
		if (read(fd, &c, 1) != 1 || expect_interrupted) {
			alarm(0);
			sigaction(SIGALRM, &oact, 0);
			if (debug)
				printf("> FAILED\n");
			return (1);
		}
		c &= 0177;
		if (debug) {
			if (c < 040)
				printf("^%c", c | 0100);
			else if (c == 0177)
				printf("^?");
			else
				printf("%c", c);
		}
		buf[nchars++] = c;
		if (nchars > expchars)
			bcopy(buf+1, buf, --nchars);
	} while (nchars < expchars || bcmp(buf, str, expchars));
	alarm(0);
	sigaction(SIGALRM, &oact, 0);
	if (debug)
		printf("> OK\n");
	return (0);
}

/*
 * Make string suitable to print out
 */
char *
printable(str)
	char *str;
{
	static char buf[128];
	char *p = buf;
	register c;

	while (c = *str++) {
		c &= 0377;
		if (c < 040) {
			*p++ = '^';
			*p++ = c | 0100;
		} else if (c == 0177) {
			*p++ = '^';
			*p++ = '?';
		} else if (c & 0200) {
			*p++ = '\\';
			*p++ = '0' + (c >> 6);
			*p++ = '0' + ((c >> 3) & 07);
			*p++ = '0' + (c & 07);
		} else
			*p++ = c;
	}
	*p = 0;
	return (buf);
}

void
wt_alarm()
{
    	longjmp(wt_env, 1);
}

/*
 * Cleanup and exit after a signal.
 */
void
cleanup(sig)
	int sig;
{
	char *signame;

	switch (sig) {
	case SIGHUP:
		signame = "SIGHUP"; break;
	case SIGINT:
		signame = "SIGINT"; break;
	case SIGTERM:
		signame = "SIGTERM"; break;
	default:
		signame = "unknown"; break;
	}
	log("%s: end of session, caught %s\n", sysname, signame);
	uu_unlock(uucplock);
	if (amup && LD != 0)
		linkscript(LD);
	ifconfig(ifname, IF, 0);
	exit(1);
}

/*
 * Run link up/down script.
 */

linkscript(path)
	char *path;
{
	char dst[16], src[16];
	struct ifreq ifr;
	int s;
	struct sockaddr_in *sa;
    	int pid;

    	dst[0] = 0;
    	src[0] = 0;

	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) != -1) {
		strncpy(ifr.ifr_name, ifname, sizeof (ifr.ifr_name));

		if (ioctl(s, SIOCGIFADDR, (caddr_t) &ifr) == -1)
			perror("ioctl(SIOCGIFADDR)");
		else {
			sa = (struct sockaddr_in *) &ifr.ifr_addr;
			strncpy(src, inet_ntoa(sa->sin_addr), sizeof (src));
		}

		if (ioctl(s, SIOCGIFDSTADDR, (caddr_t) &ifr) == -1)
			perror("ioctl(SIOCGIFDSTADDR)");
		else
			strncpy(dst, inet_ntoa(sa->sin_addr), sizeof (dst));
    	}

	if (debug)
		printf("Running \"%s %s %s %s %s\" . . . ", 
			path, sysname, ifname, src, dst);
	/*
	 * XXX - there should be a timeout
	 */
	execute(path, sysname, ifname, src, dst, 0);
	if (debug)
		printf("done.\n");
}

/*
 * Run link up/down script.
 */

loginscript(path)
	char *path;
{
	if (debug)
		printf("Running \"%s %s %s\" . . . ", path, sysname, ifname);
	/*
	 * XXX - there should be a timeout
	 */
	execute(path, sysname, ifname, 0);
	if (debug)
		printf("done.\n");
}

/*
 * Copyright (c) 1988, 1993
 *	The Regents of the University of California.  All rights reserved.
 *
 * The code below is derived from lib/libc/stdlib/system.c
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#define	MAXARGS	8

int
execute(char *script, ...)
{
    	va_list ap;
	union wait pstat;
	pid_t pid;
	int omask;
	sig_t intsave, quitsave;
	char *argv[8];
    	char **av = argv;

    	if (*av = strchr(script, '/'))
		++*av;
	else
		*av = script;
    	va_start(ap, script);
    	while (++av < &argv[MAXARGS-1] && (*av = va_arg(ap, char *)))
		;
    	va_end(ap);
	*av = 0;

	omask = sigblock(sigmask(SIGCHLD));

	switch (pid = vfork()) {
	case -1:			/* error */
		(void)sigsetmask(omask);
		pstat.w_status = 0;
		pstat.w_retcode = 127;
		warn("%s", script);
		return(pstat.w_status);
	case 0:				/* child */
    	    	if (sgid != -1)
			setuid(sgid);
    	    	if (suid != -1)
			setuid(suid);
		(void)sigsetmask(omask);
		execv(script, argv);
		_exit(127);
	}

	intsave = signal(SIGINT, SIG_IGN);
	quitsave = signal(SIGQUIT, SIG_IGN);
	pid = waitpid(pid, (int *)&pstat, 0);
	(void)sigsetmask(omask);
	(void)signal(SIGINT, intsave);
	(void)signal(SIGQUIT, quitsave);

	return (pid == -1 ? -1 : pstat.w_status);
}
