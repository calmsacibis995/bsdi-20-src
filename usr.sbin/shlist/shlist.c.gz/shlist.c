/*-
 * Copyright (c) 1995 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI shlist.c,v 2.1 1995/02/03 18:09:29 polk Exp
 */

#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <a.out.h>
#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define	N_CODEOFF(e) \
	(N_TXTOFF(e) + (__HEADER_IN_TEXT(e) ? sizeof (e) : 0))

#define	NCODEBYTES	8

struct ldtab {
	char *name;
	caddr_t address;
};

static char SHLICRT0[] = "/usr/lib/shlicrt0.o";
char codebytes[NCODEBYTES];
int ncodebytes;
struct relocation_info ltreloc;
long ltoffset;

void
init_shlicrt0()
{
	struct stat s;
	struct nlist *sym, *sym_base, *sym_end;
	struct relocation_info *r, *r_base, *r_end;
	struct exec *ep;
	caddr_t v, txt;
	char *strings;
	int f;
	int ltsym = -1;
	int low_reloc;

	if ((f = open(SHLICRT0, O_RDONLY)) == -1 ||
	    fstat(f, &s) == -1 ||
	    (v = mmap(0, s.st_size, PROT_READ, 0, f, 0)) == (caddr_t)-1)
		err(1, "%s", SHLICRT0);
	ep = (struct exec *)v;
	if (s.st_size < sizeof (*ep) || N_BADMAG(*ep))
		errx(1, "%s: %s", SHLICRT0, strerror(EFTYPE));

	/*
	 * Search the symbol table for __LIBRARY_TABLE.
	 */
	strings = (char *)(v + N_STROFF(*ep));
	sym_base = (struct nlist *)(v + N_SYMOFF(*ep));
	sym_end = sym_base + ep->a_syms / sizeof *sym_base;
	for (sym = sym_base; sym < sym_end; ++sym)
		if (sym->n_type & N_EXT && (sym->n_type & N_TYPE) == N_UNDF &&
		    strcmp(&strings[sym->n_un.n_strx], "___LIBRARY_TABLE")
			    == 0) {
			ltsym = sym - sym_base;
			break;
		}
	if (ltsym == -1)
		errx(1, "%s: can't find ___LIBRARY_TABLE symbol", SHLICRT0);

	/*
	 * Find a text relocation corresponding to __LIBRARY_TABLE.
	 * Since shlicrt0.o must start a shared library binary,
	 * we can find the address of __LIBRARY_TABLE by examining
	 * the corresponding relocated value in the binary.
	 */
	r_base = (struct relocation_info *)(v + N_DATOFF(*ep) + ep->a_data);
	r_end = r_base + ep->a_trsize / sizeof *r_base;
	low_reloc = ep->a_text;
	for (r = r_base; r < r_end; ++r) {
		if (ltreloc.r_extern == 0 && r->r_extern &&
		    r->r_symbolnum == ltsym)
			ltreloc = *r;
		if (r->r_address < low_reloc)
			low_reloc = r->r_address;
	}
	if (ltreloc.r_extern == 0)
		errx(1, "%s: can't find ___LIBRARY_TABLE relocation", SHLICRT0);

	/*
	 * Fetch the offset from the actual __LIBRARY_TABLE address.
	 */
	txt = v + N_TXTOFF(*ep);
	switch (ltreloc.r_length) {
	case 0:
		ltoffset = *(char *)(txt + ltreloc.r_address);
		break;
	case 1:
		ltoffset = *(short *)(txt + ltreloc.r_address);
		break;
	default:
		ltoffset = *(long *)(txt + ltreloc.r_address);
		break;
	}
	ltreloc.r_address -= N_CODEOFF(*ep) - N_TXTOFF(*ep);

	/*
	 * Fill in initial opcode string and length.
	 */
	low_reloc -= N_CODEOFF(*ep) - N_TXTOFF(*ep);
	ncodebytes = low_reloc < NCODEBYTES ? low_reloc : NCODEBYTES;
	bcopy(v + N_CODEOFF(*ep), codebytes, ncodebytes);

	munmap(v, s.st_size);
	close(f);
}

extern char *__progname;

int
main(argc, argv)
	int argc;
	char **argv;
{
	struct stat s;
	struct exec *ep;
	struct ldtab *lt;
	caddr_t v, ltpp;
	unsigned long ltp;
	int aflag = 0;
	int c;
	int ev = 0;
	int f;
	int o;

	while ((c = getopt(argc, argv, "a")) != EOF)
		switch (c) {
		case 'a':
			aflag = 1;
			break;
		default:
			errx(1, "usage: %s [-a] files ...", __progname);
			break;
		}
	argc -= optind;
	argv += optind;

	if (argc <= 0)
		errx(1, "usage: %s [-a] files ...", __progname);

	init_shlicrt0();

	for (; *argv; ++argv) {
		if ((f = open(*argv, O_RDONLY)) == -1 ||
		    fstat(f, &s) == -1 ||
		    (v = mmap(0, s.st_size, PROT_READ, 0, f, 0)) == (caddr_t)-1) {
			ev = 1;
			warn("%s", *argv);
			if (f != -1)
				close(f);
			continue;
		}
		ep = (struct exec *)v;
		if (s.st_size < sizeof (*ep) || N_BADMAG(*ep)) {
			ev = 1;
			warnx("%s: %s", *argv, strerror(EFTYPE));
			munmap(v, s.st_size);
			close(f);
			continue;
		}

		printf("%s:", *argv);

		/* if it doesn't start with shlicrt0.o, skip it */
		if (bcmp(v + N_CODEOFF(*ep), codebytes, ncodebytes)) {
			putchar('\n');
			munmap(v, s.st_size);
			close(f);
			continue;
		}

		/*
		 * Extract the relocated address of __LIBRARY_TABLE.
		 * XXX m68k pcrel rules?
		 */
		ltpp = v + N_CODEOFF(*ep) + ltreloc.r_address;
		switch (ltreloc.r_length) {
		case 0:
			ltp = *(unsigned char *)ltpp - ltoffset;
			if (ltreloc.r_pcrel)
				ltp += ltreloc.r_address + sizeof (char);
			break;
		case 1:
			ltp = *(unsigned short *)ltpp - ltoffset;
			if (ltreloc.r_pcrel)
				ltp += ltreloc.r_address + sizeof (short);
			break;
		default:
			ltp = *(unsigned long *)ltpp - ltoffset;
			if (ltreloc.r_pcrel)
				ltp += ltreloc.r_address + sizeof (long);
			break;
		}

		/*
		 * Iterate through __LIBRARY_TABLE, printing names.
		 */
		o = N_TXTOFF(*ep) - N_TXTADDR(*ep);
		lt = (struct ldtab *)(v + o + ltp);
		for (; lt->name; ++lt) {
			printf(" %s", (char *)(v + o + (unsigned)lt->name));
			if (aflag)
				printf("<%#10x>", (unsigned)lt->address);
		}
		putchar('\n');

		munmap(v, s.st_size);
		close(f);
	}

	return (ev);
}
