/*-
 * Copyright (c) 1993 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 */
 
/*	BSDI pathnames.h,v 2.1 1995/02/03 17:24:05 polk Exp	*/

#include <paths.h>

/* XXX - use relative pathnames and expect them to be in 
	 the users path.  Security problem? */

#define _PATH_ECHO		"echo"
#define _PATH_RSH		"rsh -n"
#define _PATH_DD		"dd"
#define _PATH_UNZIP		"gzcat -q"
#ifndef _PATH_UNCOMPRESS
#define _PATH_UNCOMPRESS	"zcat"
#endif
#define _PATH_MT		"mt"
#define _PATH_TAR		"tar"
#define _PATH_PAX		"pax"
#define _PATH_CAT		"cat"
#define _PATH_RM		"rm"
