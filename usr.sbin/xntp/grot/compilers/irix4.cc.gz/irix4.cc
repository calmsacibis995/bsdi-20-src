COMPILER= cc -cckr
COPTS= -O2
