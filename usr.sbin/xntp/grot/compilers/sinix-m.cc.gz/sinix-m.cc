COMPILER= /usr/ucb/cc
