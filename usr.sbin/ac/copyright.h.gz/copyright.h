/*
 * This program is Copyright (c) 1992 Jiffy Script, Inc.
 * 
 * - Source should be made available to anyone who requests it.
 * - It is forbidden to charge anyone more for this program than
 * 	you have been charged.  That it to say, if you got it
 *	for free, you must give it for free.  And, since we did 
 *	not charge for the first copy, if you were charged, you
 *	have been taken.
 * - This agreement must remain with the program.
 * - Please comment any changes you make.  We would not want anyone
 *	to think that your fixes were a flash of brilliance on our part.
 * - We will try to fix the program if it breaks, but we offer no
 *	guarantees.  Furthermore, we will not be held liable for any
 *	damage, be it physical or psychological, resulting from the use
 *	of the program.
 */

