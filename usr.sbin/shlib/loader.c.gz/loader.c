/*-
 * Copyright (c) 1994 Berkeley Software Design, Inc. All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	BSDI loader.c,v 2.1 1995/02/03 18:09:01 polk Exp
 */

asm (".text; jmp _loader");

#include <sys/param.h>
#include <sys/exec.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/*
 * Internal bootstrap for fixed-address static shared libraries.
 * Called from a stub in programs that use static shared libraries.
 * The loader is always presumed to be embedded in the C library.
 * Currently we also assume that the loader is in QMAGIC format.
 */

/*
 * Structure of the library table __LIBRARY_TABLE[].
 * The address is the base address of the library's text;
 * the loader maps the first page and calls address+32
 * to complete the initialization.
 * The loader itself is the first element in the table.
 */
struct ldtab {
	char *name;
	caddr_t address;
};

#define	DATA_OFFSET	0x400000

#ifdef LIBC
extern unsigned long _minbrk;
extern unsigned long curbrk asm("curbrk");

#define	PS_STRINGS1_1	(0xefc00000 - 2 * NBPG - sizeof(struct ps_strings))

char **environ = 0;
char *__progname = 0;
struct ps_strings *__ps_strings = 0;
#endif

/* don't forget the obnoxious pad word */
caddr_t __mmap __P((caddr_t, size_t, int, int, int, int, off_t));

void
#ifdef LIBC
loader(int (*main)(int, char **, char **), long heap, struct ps_strings *psp,
    struct ldtab *lp, int f)
#else
loader(struct ldtab *lp, int f)
#endif
{
	struct exec *e = (struct exec *)lp->address;
#ifdef LIBC
	void (*fp)(struct ldtab *, int);
	char *p, *s;
#endif

	if (__mmap(lp->address + NBPG, e->a_text - NBPG, PROT_READ|PROT_EXEC,
	      MAP_PRIVATE|MAP_FIXED, f, 0, NBPG) == (caddr_t)-1 ||
	    __mmap(lp->address + DATA_OFFSET, e->a_data,
	      PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_FIXED, f,
	      0, e->a_text) == (caddr_t)-1 ||
	    __mmap(lp->address + DATA_OFFSET + e->a_data, e->a_bss,
	      PROT_READ|PROT_WRITE|PROT_EXEC, MAP_ANON|MAP_FIXED, -1, 0, 0)
	      == (caddr_t)-1)
		__abort();

#ifdef LIBC
	close(f);

	/* Note that we have no data segment until the mmap()s finish! */
	_minbrk = curbrk = heap;
	if (psp == 0)
		psp = (struct ps_strings *)PS_STRINGS1_1;
	__ps_strings = psp;
	environ = psp->ps_envp;
	if ((p = *psp->ps_argv) != NULL) {
		s = strrchr(p, '/');
		__progname = s ? s + 1 : p;
	} else
		__progname = "";

	for (++lp; lp->name; ++lp) {
		if ((f = open(lp->name, O_RDONLY)) == -1 ||
		    __mmap(lp->address, NBPG, PROT_READ|PROT_EXEC,
		      MAP_PRIVATE|MAP_FIXED, f, 0, 0) == (caddr_t)-1) {
			write(STDERR_FILENO, "can't open `", 12);
			write(STDERR_FILENO, lp->name, strlen(lp->name));
			write(STDERR_FILENO, "'\n", 2);
			__abort();
		}
		fp = (void (*)(struct ldtab *, int))
		    (lp->address + sizeof (struct exec));
		(*fp)(lp, f);
		close(f);
	}

	exit((*main)(psp->ps_argc, psp->ps_argv, psp->ps_envp));
#endif
}

asm (".text; 0: jmp ___cerror; .align 2; ___mmap: leal 197,%eax; lcall $7,$0; jb 0b; ret");
asm (".text; .align 2; ___cerror: movl $-1,%eax; ret");
asm (".text; .align 2; ___abort: hlt");

asm (".text; .org 4096 - 32");
