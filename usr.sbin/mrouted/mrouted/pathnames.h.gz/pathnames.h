/*
 * Copyright (c) 1994 Berkeley Software Design, Inc.
 * All rights reserved.
 * The Berkeley Software Design Inc. software License Agreement specifies
 * the terms and conditions for redistribution.
 *
 *	pathnames.h,v 2.1 1995/02/03 17:28:32 polk Exp
 */

#define	PATH_CONFIGFILE	"/etc/mrouted.conf"
#define	PATH_DUMPFILE	"/var/tmp/mrouted.dump"
#define	PATH_PIDFILE	"/var/run/mrouted.pid"
