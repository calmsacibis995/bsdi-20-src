/*
 * /master/usr.sbin/sa/pathnames.h,v 2.1 1995/02/03 17:55:11 polk Exp
 * pathnames.h,v
 * Revision 2.1  1995/02/03  17:55:11  polk
 * Update all revs to 2.1
 *
 * Revision 1.2  1994/11/08  21:21:45  polk
 * lite merge
 *
 * Revision 1.1.1.1  1992/09/25  19:11:41  trent
 * Initial import of sa from andy@terasil.terasil.com (Andrew H. Marrinson)
 *
 * Revision 1.2  1992/05/12  18:02:35  andy
 * Changed RCS ids.
 *
 */
#include <paths.h>


#define _PATH_ACCT "/var/account/acct"
#define _PATH_COMMAND_SUMMARY "/var/account/savacct"
#define _PATH_USER_SUMMARY "/var/account/usracct"
