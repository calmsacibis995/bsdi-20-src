#!/usr/bin/perl

#
# Copyright (c) 1994,1995 Berkeley Software Design, Inc.
# All rights reserved.
# The Berkeley Software Design Inc. software License Agreement specifies
# the terms and conditions for redistribution.
#
#	BSDI	configure_all.pl,v 2.1 1995/02/03 17:08:18 polk Exp

require '/etc/adm/lib/adm.pl';

# Make sure we're running as root
if ($> != 0) {
        print "$0: this program must be run as root!\n";
        exit 1;
}

$| = 1;  # Make STDOUT unbuffered...

print <<ETX;

-----------------------------------------------------------------------

Welcome to BSD/OS 2.0 system configuration...

You will be asked general questions necessary for initial 
configuration of the system.  Once you have completed configuration, 
the system will continue booting to multi-user mode.

If you do not wish to follow the normal configuration procedure, 
type <Control>-C and you will be placed in the single-user shell.

ETX
&query("Press <Enter> to continue");
print "\n";

# explain the rules...
&explain;

# Configure netstart
system("$ADMBIN/config_netstart -n");

# Set the timezone
&set_timezone;

# Set the root password
for (;;) {
	print <<ETX;
Please set the super-user (root) password for this machine.  The
password will not be displayed on the screen.

ETX
	if ( -f "/usr/sbin/kerberos" ) {
		$pwcmd = "/usr/bin/passwd -l root";
	}
	else {
		$pwcmd = "/usr/bin/passwd root";
	}
	last if !system($pwcmd);
}
print "\n";

# Set up DNS
print <<ETX;
Do you wish to set up this machine as the primary name server
for your local domain?  If so, you may do that at this time.
If you wish to set it up later or to modify the setup, you 
can always use `config_dns' command.

ETX
$_ = &query("Configure this system as the primary DNS server now?", "no");
if (/^[yY]/) {
	system("$ADMBIN/config_dns -k");
}
else {
	print <<ETX;
If you already have a nameserver available, you can tell 
the system to resolve names by sending requests to the remote
server (specified in /etc/resolv.conf).  You will need to know
the IP address of the remote server to configure the resolver.

ETX
	$_ = &query("Do you wish to configure DNS to talk to a remote server now?", "yes");
	/^[yY]/ && &config_resolver;
}

# Set up anonymous ftp server XXX

# Set up WWW server
if ( -d $WWWHOME ) {
	print <<ETX;
If you wish to set up a World-Wide-Web (http) server on this 
machine, you may do so now.  If you wish to set it up later or to modify 
the setup, you can always use the `config_www' command.

ETX
	$_ = &query("Do you wish to configure a WWW server now?", "no");
	/^[yY]/ && system("$ADMBIN/config_www -k -n");
}

print <<ETX;
The next configuration step is to create a system administrator
login.  This user will receive root's mail (e.g., daily reports,
mail to postmaster, etc.) and will be added to the wheel group so
that they may use the `su' command to become root.

ETX
$_ = &query("Create system administrator login now?", "yes");
&create_admin_login if /^[Yy]/;

print <<ETX;
If you wish to install any of the packages distributed on floppies, 
you may do so at this time.  If you wish to install additional 
packages later, you can always use the `installfloppy' command.

ETX
for (;;) {
	$_ = &query("Do you wish to install packages from a floppy now?", 
			"no");
	last if /^[nN]/;
	system("installfloppy") && print STDERR "$0: installfloppy failed\n";
}

print <<ETX;

Initial configuration completed successfully.

Login as root and add users with the `adduser' command...

ETX
&query("Press <Enter> to continue.");

exit 0;

sub set_timezone {
	local($_, @_, @uszones, @allzones);

	$_ = `/bin/ls $TZDIR/US` || do {
		print STDERR "$0: couldn't get timezone information\n";
		return;
	};
	chop;
	@uszones = split;
	for (;;) {
		print <<ETX;
The following timezones are available for the United States.  If
you are not in the US, or you need one of the other special timezones,
enter `other' at this prompt and you will be given the chance to
select from the complete list.

ETX
		&printlist("US Timezones:\n", @uszones);
		print "\n";
		$_ = &query("Which timezone (`other' to see other choices)?");
		print "\n";
		last if /other/;
		for $i (@uszones) {
			if (/$i/i) {
				system("cp $TZDIR/US/$i /etc/localtime") && print STDERR "$0: couldn't copy timezone information into place \n";
				return;
			}

		}
		print "Invalid selection ($i).\n\n";
	}

	$_ = `/usr/bin/find $TZDIR -type f -print` || do {
		print STDERR "$0: couldn't get timezone information\n";
		return;
	};
	chop;
	split;
	for $_ (@_) {
		
		s#$TZDIR/##;
		/^SystemV/ && next;
# XXX -- Skip these?
#		/^US/ && next;
#		/^GMT/ && next;
		$allzones[++$#allzones] = $_;
	}
	for (;;) {
		&printlist("Available Timezones:\n", @allzones);
		print "\n";
		$_ = &query("Which timezone (`none' to skip setting timezone)?");
		print "\n";
		return if /none/;
		for $i (@allzones) {
			if (/$i/i) {
				system("cp $TZDIR/$i /etc/localtime") && print STDERR "$0: couldn't copy timezone information into place \n";
				return;
			}
		}
		print "Invalid selection ($i).\n\n";
	}

}

sub config_resolver {
	for (;;) {
        	print <<ETX;
Enter the IP address of the machine which runs the 
local name service (e.g., 192.0.0.23).

ETX
        	$_ = &query("IP address of nameserver machine?");
        	print "\n";
        	$ipaddr = $_;
        	last if /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
        	print STDERR "Invalid entry: $_\n\n";
		$_ = &query("Do you still wish to configure the resolver?", "no");
		print "\n";
		return if ! /^[Yy]/;
	}
	system("cp $RESOLV $RESOLV.bak >/dev/null 2>&1");
	open (OUT, ">$RESOLV") || die "$0: couldn't open $RESOLV for writing\n";
	print OUT "nameserver $ipaddr\n";
	close (OUT);
}

sub create_admin_login {
	for (;;) {
		print <<ETX;
Enter the login name of the system administrator for this site.  If 
the account does not already exist, you will be prompted for the 
information necessary to create it.  This account will receive mail
addressed to "root", "postmaster", and several other system aliases.

ETX
		$_ = &query("System administrator login?", $login);
		print "\n";
		if (!/^[a-zA-Z][a-zA-Z0-9]*$/ || length($_) > 16) {
			print <<ETX;
Login names must be 16 characters or fewer, must start with a letter, 
and may contain only letters and digits.

ETX
			next;
		}
		$login = $_;
		$_ = &query("Is `$login' the correct name?", "yes");
		print "\n";
		last if /^[yY]/;
	}
	if (!`grep ^$login $PASSWD`) {
		# Create the account
		system("$ADMBIN/adduser $login");
	
		# Put it in the wheel group for su
		&parsegroup;
		$members{"wheel"} .= ",$login";
		&writegroup;
	}
	
	# Update the root alias (if it's still a comment)
	if ($login ne "root") {
		system("cp $ALIASES $ALIASES.bak") && die "$0: couldn't save backup copy of $ALIASES\n";
		open (IN, "$ALIASES.bak") || die "$0: couldn't open copy of $ALIASES for reading\n";
		open (OUT, ">$ALIASES") || die "$0: couldn't open $ALIASES for writing\n";
		while (<IN>) {
			s/^#root:.*/root:\t$login/;
			print OUT $_;
		}
		close(IN);
		close(OUT);
	}
}
