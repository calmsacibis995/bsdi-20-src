#!/usr/bin/perl

#
# Copyright (c) 1994 Berkeley Software Design, Inc.
# All rights reserved.
# The Berkeley Software Design Inc. software License Agreement specifies
# the terms and conditions for redistribution.
#
#	BSDI	config_netstart.pl,v 2.1 1995/02/03 17:08:05 polk Exp

require '/etc/adm/lib/adm.pl';

# Make sure we're running as root
if ($> != 0) {
        print "$0: this program must be run as root!\n";
        exit 1;
}

$| = 1;  # Make STDOUT unbuffered...

require 'getopts.pl';
&Getopts('n') || die "Usage: $0\n";

# read the current settings for netstart
&readsimple($NETSTART_DEF, 0);
%netstart = %fields;

# explain the rules...
&explain if !$opt_n;

# set up a label so we can do it all over again...
restart:

# Host name
for (;;) {
	print <<ETX;
The host name for a machine should be the fully qualified 
name of the machine (e.g., myhost.mydomain.com).  Host names
and domain names can consist of letters, numbers, and `_'.

ETX
	$_ = &query("Host name for this machine?", $netstart{"HOST"});
	print "\n";
	if (!/\./) {
		print <<ETX;
The name you entered ($_) does not appear to be a fully qualified
host name.  The hostname MUST be the fully qualified name (including
the domain part).

ETX
		next;
	}
	last if /^[-A-Za-z0-9_\.]+$/;
}
$host = $_;
$netstart{"HOST"} = $host;

# IP Address
$tries=0;
$ipaddr="";
for (;;) {
	print <<ETX;
Ethernet interfaces enable the machine to talk to remote hosts over
the local ethernet or LAN.  Each network interface has an associated
IP (internet protocol) address which is written as a group of four
numbers (each between 0 and 255 inclusive) separated by periods
(e.g., 192.0.0.23).  The first three numbers are usually the
network number (assigned to your site by either the NIC (network
information center) or your service provider).  The last number is
the host address within your network and is usually chosen locally.
The host addresses of 0 and 255 have special meanings and should
never be used for network interfaces.  The addresses between 1 and
254 (inclusive) can be used for hosts.  

ETX
	$_ = &query("Do you wish to configure an ethernet interface?", 
		$tries ? "no" : "yes");
	print "\n";
	if (!/^[yY]/) {
		undef $netstart{"ADDR"};
		undef $netstart{"IFACE"};
		undef $netstart{"ITYPE"};
		undef $netstart{"MASK"};
		undef $netstart{"DEFRT"};
		last;
	}
	print "Enter the IP address of this machine (e.g., 192.0.0.23).\n\n";
	$_ = &query("IP address of this machine?", $netstart{"ADDR"});
	print "\n";
	$ipaddr = $_;
	last if /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
	print STDERR "Invalid entry: $_\n\n";
	$tries++;
}
$netstart{"ADDR"} = $ipaddr if $ipaddr ne "";

# Ethernet interface
@iface_names=("pe", "xir", "ne", "eo", "ep", "tn", "hpp", "re", 
	      "we", "ef", "el", "ex");
@iface_types=(
	"Xircom PE-2 (pe)",
	"Xircom PE-3 (xir)",
	"Novell NE-1000/NE-2000 (ne)",
	"3com 3c505 (eo)",
	"3com Etherlink Plus (3c505) (ep)",
	"TNIC-1500 (tn)",
	"HP EtherTwist (hpp)",
	"Allied Telesis RE2000/AT-1700 (re)",
	"WD/SMC Elite/Ultra & 3com 3c503 (we)",
	"3com Etherlink III (3c509/3c579) (ef)",
	"3com Etherlink 16 (3c507) (el)",
	"Intel EtherExpress 16 (ex)",
);

if ($ipaddr ne "") {
	local(@menu, $oldiface);

	# Ethernet interface

	$oldiface = -1;
	for ($i=0; $i<=$#iface_names; $i++) {
		$_ = sprintf("%s) $iface_types[$i]", $i+1);
		push(@menu, $_);
		$oldiface = $i if $netstart{"IFACE"} eq $iface_names[$i];
	}
	for (;;) {
		&printlist("Supported ethernet interface types:\n", @menu);
		print "\n";
		$_ = &query("Interface type?", $oldiface+1);
		print "\n";
		last if $_ <= $#iface_names+1;
	}
	$iface = $iface_names[$_-1];
	undef $netstart{"ITYPE"} if $iface ne $netstart{"IFACE"};
	$netstart{"IFACE"} = $iface;

	# Interface type

	if ($iface eq "we" || $iface eq "ef" || $iface eq "hpp" ||
		$iface eq "el") {
		for (;;) {
			print <<ETX;
Some models of your ethernet card support multiple types of 
interface (e.g., AUI, BNC, 10baseT (TP)).  In order to configure 
the driver for your card, you must specify which interface type
you will be using.

The BNC interface is for the COAXial cable connectors (a.k.a
thin-net).  They have a single pin in the middle and you twist them
to lock them onto the connector.  TP is short for `twisted pair'.
The connector for TP interfaces looks like a wide modular phone
connector.  AUI is used with an external tranceiver -- it has a
15-pin DB style connector that looks sort of like a serial port
connector.

If your card has hardware configuration jumpers to set the 
interface type, you will need to have those configured correctly
as well for the interface to work properly.

ETX
			$_ = &query("Which interface type? (AUI, BNC, TP)",
					$netstart{"ITYPE"}, ("AUI", "aui",
					"BNC", "bnc", "TP", "tp"));
			print "\n";
			last if /aui/i || /bnc/i || /tp/i;
		}
		tr/a-z/A-Z/;
		$netstart{"ITYPE"} = $_;
		$linkarg = "link0" if $iface eq "we" && $_ eq "BNC";
		$linkarg = "link0" if $iface eq "ef" && $_ eq "BNC";
		$linkarg = "link1" if $iface eq "ef" && $_ eq "TP";
		$linkarg = "link0" if $iface eq "hpp" && $_ eq "TP";
	}

	# netmask

	for (;;) {
		print <<ETX;
If you are using a non-standard netmask, you can enter the netmask
you wish to use (in standard dotted quad notation: i.e., 255.255.255.0)
here.  For most sites (or if you don't know), just accept the default
value.

ETX
		$_ = &query("Netmask (`default' to use the default net mask)?", defined($netstart{"MASK"}) ? $netstart{"MASK"} : "default");
		print "\n";
		last if $_ eq "default";
		last if /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
	}
	if ($_ eq "default") {
		undef $netstart{"MASK"};
	}
	else {
		$netstart{"MASK"} = $_;
		$mask = $_;
	}

	# Default route?
	for (;;) {
		print <<ETX;
A ``default route'' is used to specify the IP address of the host which 
should receive packets destined for machines that aren't on your local 
network.  If you are using a router (e.g., CISCO), you should specify
the IP address of that router.  If you are using this BSD system as the 
router, you should NOT specify a ``default route.''

ETX
		$_ = &query("IP address of router (`none' for no default route)?", defined($netstart{"DEFRT"}) ? $netstart{"DEFRT"} : "none");
		print "\n";
		last if $_ eq "none";
		last if /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
		print "Invalid entry: $_\n\n";
	}
	if ($_ eq "none") {
		undef $netstart{"DEFRT"};
	}
	else {
		$netstart{"DEFRT"} = $_;
		$defrt = $_;
	}
}

print <<ETX;
You have now answered all the questions necessary for basic network
configuration.  If you didn't make any mistakes while entering your
answers, simply continue and the appropriate configuration files
will be written to your hard disk.

If you wish to exit this program without writing out the configuration
files, type <Control>-C.

Here are your current answers:

ETX
print "\tHost Name:\t\t$netstart{\"HOST\"}\n";
printf "\tIP Address:\t\t%s\n", $netstart{"ADDR"} ? $netstart{"ADDR"} : "(none)";
for ($i=0; $i <= $#iface_names; $i++) {
	last if $iface_names[$i] eq $netstart{"IFACE"};
}
printf "\tEthernet interface:\t%s%s\n", $i <= $#iface_names ? $iface_types[$i] : "(none)", $netstart{"ITYPE"} ? " ($netstart{\"ITYPE\"})" : "";
printf "\tSpecial Netmask:\t%s\n", $netstart{"MASK"} ? $netstart{"MASK"} : "(none)";
printf "\tDefault Route:\t\t%s\n", $netstart{"DEFRT"} ? $netstart{"DEFRT"} : "(none)";
print "\n";
$_ = &query("Do you wish to go through the questions again?", 
		$looptries++ ? "no" : "yes");
print "\n";
goto restart if /^[yY]/;

&writesimple($NETSTART_DEF, %netstart);

open (TMP, ">$ETC/netstart.tmp") || 
	die "$0: can't open $ETC/netstart.tmp: $!\n";
print TMP <<ETX;
#
# netstart - configure network daemons, interfaces, and routes
#
# Do not change lines above the `DO NOT DELETE THIS LINE' line.  They
# are generated by the $0 program.  You can change them by re-running
# that program or by placing additional assignments (or other changes)
# after that line.
#
ETX
print TMP "\n";
print TMP "hostname=$host\n";
if ($iface ne "") {
	print TMP "iface=${iface}0\n";
}
else {
	print TMP "iface=\n";
}
print TMP "ipaddr=$ipaddr\n";
print TMP "linkarg=$linkarg\n";
print TMP "netmask=$mask\n";
print TMP "defroute=$defrt\n";
print TMP "\n# DO NOT DELETE THIS LINE -- make local changes below here\n";

$got_netstart=1;
if (open (NETSTART, "$ETC/netstart")) {
	while (<NETSTART>) {
		/^# DO NOT DELETE THIS LINE/ && last;
	}
	if (eof(NETSTART)) {
		$got_netstart = 0;
		$tmp = "$ETC/netstart.bak";
		while (-f $tmp) {
			$tmp .= ".bak";
		}
		print <<ETX;
You appear to have an old-style netstart file (without the 
machine generated part).  A copy of that version of the file 
will be saved in $tmp.

ETX
		system("/bin/cp $ETC/netstart $tmp") && 
			print STDERR "$0: WARNING: can't save old netstart\n";
	}
	else {
		while (<NETSTART>) {
			print TMP $_;
		}
	}
	close NETSTART;
}
else {
	# No error for now if netstart didn't exist
	# print STDERR "$0: WARNING: can't open $ETC/netstart: $!\n";
	$got_netstart=0;
}

if (!$got_netstart) {
	open (PROTO, "$CONFIGPATH/proto/netstart") ||
		die "$0: can't open $CONFIGPATH/proto/netstart: $!\n";
	while (<PROTO>) {
		print TMP $_;
	}
	close PROTO;
}

close TMP;
rename ("$ETC/netstart.tmp", "$ETC/netstart") || 
	die "$0: can't rename $ETC/netstart.tmp into place: $!\n";

#
# Make sure there's an entry for the local host name in /etc/hosts
#
$ipaddr="127.1" if $ipaddr eq "";
open (TMP, ">$ETC/hosts.tmp") || 
	die "$0: can't open $ETC/hosts.tmp: $!\n";
if (open (HOSTS, "$ETC/hosts")) {
	while (<HOSTS>) {
		/#/ && do { print TMP $_; next; };
		/\s$host\s/ && do { $hostline=$_; next; };
		print TMP $_;
	}
}
close HOSTS;
if ($hostline ne "") {
	$hostline =~ s/[\d\.]+\s/$ipaddr\t/;
}
else {
	$hostline = "$ipaddr\t$host\n";
}
print TMP $hostline;
close TMP;
rename ("$ETC/hosts.tmp", "$ETC/hosts") || 
	die "$0: can't rename $ETC/hosts.tmp into place: $!\n";

print "$ETC/netstart configuration completed successfully.\n";
if (!$opt_n) {
	print "These changes will take effect at the next reboot.\n";
}
print "\n";

exit 0;
