#! /bin/sh -
#	BSDI dvi2ps-filter.sh,v 2.1 1995/02/03 17:25:43 polk Exp
IFS=""; export IFS
PATH="/bin:/usr/bin"; export PATH
trap "/bin/rm -f /tmp/dvips.$$.dvi" 0
cat > /tmp/dvips.$$.dvi || exit 2
/usr/contrib/bin/dvips -f /tmp/dvips.$$.dvi 2>/dev/null | /usr/contrib/bin/lprps "$@" || exit 2
exit 0
