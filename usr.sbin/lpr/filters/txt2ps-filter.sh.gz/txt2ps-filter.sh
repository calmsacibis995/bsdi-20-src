#! /bin/sh -
#	BSDI txt2ps-filter.sh,v 2.1 1995/02/03 17:25:53 polk Exp
IFS=""; export IFS
PATH="/bin:/usr/bin"; export PATH
/usr/contrib/bin/textps || exit 2
exit 0
