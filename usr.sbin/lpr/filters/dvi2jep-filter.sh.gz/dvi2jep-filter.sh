#! /bin/sh -
#	BSDI dvi2jep-filter.sh,v 2.1 1995/02/03 17:25:40 polk Exp
IFS=""; export IFS
PATH="/bin:/usr/bin"; export PATH
printf '\033E'
trap "/bin/rm -f /tmp/dvijep.$$.*; printf '\033E'" 0
cat > /tmp/dvijep.$$.dvi || exit 2
/usr/contrib/bin/dvilj4 -r -q /tmp/dvijep.$$.dvi || exit 2
cat /tmp/dvijep.$$.dvi-jep || exit 2
exit 0
